# Шаблон PR

```markdown
## Задача
- Tracker: <link>
- Figma: <exact node links>
- Платформа: <iOS | Android | Web>

## Что изменилось
<наблюдаемый результат для пользователя>

## Переиспользование
- <existing component/token/pattern and why>

## Состояния и снимки
| state | test/story | snapshot | design review |
|---|---|---|---|

## Проверки
- <command>: <result>

## Нужен ревью разработчика
<confirmed owner/reviewer or explicit unresolved owner>

## Риски и вопросы
- none | <exact unresolved item>
```

Не вставляй в PR сырые логи, неподтверждённые имена владельцев или общий Figma-холст вместо точных узлов.
