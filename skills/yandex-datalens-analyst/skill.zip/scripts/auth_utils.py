#!/usr/bin/env python3
"""Shared OAuth helpers — строго skotty (OAuth через SSH-agent)."""

from __future__ import annotations

import getpass
import json
import os
import platform
import socket
import struct
import time
from base64 import urlsafe_b64encode
from urllib import error, parse, request

DEFAULT_OAUTH_URL = "https://oauth.yandex-team.ru/token"
DEFAULT_CLIENT_ID = os.environ.get("DATALENS_OAUTH_CLIENT_ID", "")
DEFAULT_CLIENT_SECRET = os.environ.get("DATALENS_OAUTH_CLIENT_SECRET", "")


class TokenError(RuntimeError):
    pass


_SKOTTY_HEADER = (
    "\n=== Как установить skotty ===\n"
    "Skotty — SSH-агент для работы с Яндексовым PKI (Yubikey / Secure Enclave).\n\n"
    "Быстрая установка (через ya):\n"
    "  ya tool skotty --self-install\n\n"
)

_SKOTTY_MANUAL = {
    "Darwin": (
        "Ручная установка (macOS):\n"
        "  wget https://tools.sec.yandex-team.ru/api/v1/release/skotty-launcher/darwin/latest/skotty-launcher -O /tmp/skotty-launcher\n"
        "  xattr -c /tmp/skotty-launcher && chmod +x /tmp/skotty-launcher\n"
        "  sudo /tmp/skotty-launcher --self-install\n"
    ),
    "Linux": (
        "Ручная установка (Linux):\n"
        "  wget https://tools.sec.yandex-team.ru/api/v1/release/skotty-launcher/linux/latest/skotty-launcher -O /tmp/skotty-launcher\n"
        "  chmod +x /tmp/skotty-launcher && sudo /tmp/skotty-launcher --self-install\n"
    ),
    "Windows": (
        "Ручная установка (Windows, PowerShell от администратора):\n"
        "  Invoke-WebRequest -Uri https://tools.sec.yandex-team.ru/api/v1/release/skotty-launcher/windows/latest/skotty-launcher.exe -OutFile $env:TEMP\\skotty-launcher.exe\n"
        "  & $env:TEMP\\skotty-launcher.exe --self-install\n"
        "  # После установки перезапустите терминал\n"
        "  # SSH_AUTH_SOCK задаётся автоматически через именованный pipe\n"
    ),
}

_SKOTTY_FOOTER = (
    "\nПосле установки:\n"
    "  skotty setup          # настроить Yubikey / Secure Enclave\n"
    "  skotty service enable  # автозагрузка\n"
    "  skotty service start   # запустить\n"
    "  ssh-add -l             # проверить ключи\n"
    "\nПроверка:\n"
    "  ssh insecure@skotty.sec.yandex.net  # должен показать 'Everything seems to be working fine'\n"
    "\nДокументация: https://docs.yandex-team.ru/skotty/quick-start-guide\n"
    "Поддержка:    https://nda.ya.ru/t/4A8PXam47BvGvu (Telegram)\n"
)


def _get_skotty_install_guide() -> str:
    """Вернуть инструкцию по установке skotty для текущей ОС."""
    system = platform.system()
    manual = _SKOTTY_MANUAL.get(system)
    if manual:
        return _SKOTTY_HEADER + manual + _SKOTTY_FOOTER
    return _SKOTTY_HEADER + "\n".join(_SKOTTY_MANUAL.values()) + _SKOTTY_FOOTER


SKOTTY_INSTALL_GUIDE = _get_skotty_install_guide()


def _b64u_encode(data: bytes) -> str:
    return urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _build_ssh_string(data: bytes | str) -> bytes:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return struct.pack(">I", len(data)) + data


def _parse_ssh_string(data: bytes, offset: int) -> tuple[bytes, int]:
    str_len = struct.unpack(">I", data[offset:offset + 4])[0]
    offset += 4
    return data[offset:offset + str_len], offset + str_len


def _recv_all(sock: socket.socket, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise TokenError("SSH agent: connection closed")
        buf.extend(chunk)
    return bytes(buf)


def _parse_oauth_error(raw: str) -> str:
    """Разобрать ошибку OAuth и вернуть понятное сообщение с инструкцией."""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return f"Неизвестная ошибка OAuth: {raw[:300]}"

    err = data.get("error", "")
    desc = data.get("error_description", "")

    if err == "invalid_client" and "secret" in desc.lower():
        return (
            f"Неверный client_secret для client_id={DEFAULT_CLIENT_ID}.\n"
            "Решение: проверьте переменные DATALENS_OAUTH_CLIENT_ID и "
            "DATALENS_OAUTH_CLIENT_SECRET. Текущая пара может не соответствовать OAuth-приложению."
        )
    if err == "invalid_client":
        return (
            f"OAuth-приложение с client_id={DEFAULT_CLIENT_ID} не найдено или отключено.\n"
            "Решение: проверьте переменную DATALENS_OAUTH_CLIENT_ID.\n"
            f"Детали: {desc}"
        )
    if err == "invalid_grant":
        return (
            f"SSH-подпись отклонена OAuth-сервером: {desc}\n"
            "Решение: убедитесь что skotty запущен и ключ актуален (ssh-add -l).\n"
            "Если ключ протух — перезапустите skotty."
        )
    if err == "unauthorized_client":
        return (
            f"OAuth-приложение не поддерживает grant_type=ssh_key: {desc}\n"
            "Решение: это приложение не настроено для SSH-авторизации.\n"
            "Используйте другую одобренную пару client_id/client_secret."
        )
    return f"OAuth ошибка: {err} — {desc}" if desc else f"OAuth ошибка: {raw[:300]}"


def get_token_via_ssh(
    client_id: str = DEFAULT_CLIENT_ID,
    client_secret: str = DEFAULT_CLIENT_SECRET,
    *,
    login: str | None = None,
    oauth_url: str = DEFAULT_OAUTH_URL,
) -> str:
    """Get OAuth token through SSH agent (skotty)."""
    if not client_id or not client_secret:
        raise TokenError(
            "Не заданы DATALENS_OAUTH_CLIENT_ID и DATALENS_OAUTH_CLIENT_SECRET. "
            "Получите параметры приложения через одобренный внутренний процесс и "
            "передайте их только через переменные окружения. Не сохраняйте их в Git."
        )
    sock_path = os.environ.get("SSH_AUTH_SOCK")
    if not sock_path:
        raise TokenError(
            "SSH_AUTH_SOCK не задан — skotty не запущен или не установлен.\n"
            "Решение:\n"
            "  1. Если skotty установлен: skotty service start\n"
            "  2. Проверьте: echo $SSH_AUTH_SOCK && ssh-add -l\n"
            "  3. Повторите команду\n"
            + SKOTTY_INSTALL_GUIDE
        )

    login = login or getpass.getuser()
    ts = int(time.time())
    string_to_sign = f"{ts}{client_id}{login}"

    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect(sock_path)
    except FileNotFoundError:
        sock.close()
        raise TokenError(
            f"Сокет SSH-агента не найден: {sock_path}\n"
            "Решение: skotty не запущен или SSH_AUTH_SOCK указывает на несуществующий файл.\n"
            "  1. Перезапустите skotty: skotty service start\n"
            "  2. Проверьте: ls -la $SSH_AUTH_SOCK\n"
            + SKOTTY_INSTALL_GUIDE
        )
    except ConnectionRefusedError:
        sock.close()
        raise TokenError(
            f"SSH-агент отклонил соединение: {sock_path}\n"
            "Решение: skotty завис или сокет устарел.\n"
            "  1. Перезапустите skotty\n"
            "  2. Проверьте: ssh-add -l"
        )
    except OSError as e:
        sock.close()
        raise TokenError(
            f"Не удалось подключиться к SSH-агенту: {e}\n"
            "Решение: проверьте что skotty запущен (ssh-add -l)"
        ) from e

    try:
        sock.sendall(struct.pack(">IB", 1, 11))
        resp_len = struct.unpack(">I", _recv_all(sock, 4))[0]
        resp = _recv_all(sock, resp_len)
        if resp[0] != 12:
            raise TokenError(
                f"SSH-агент вернул неожиданный ответ (код {resp[0]} вместо 12).\n"
                "Решение: возможно SSH_AUTH_SOCK указывает не на skotty.\n"
                "  Проверьте: ssh-add -l"
            )

        nkeys = struct.unpack(">I", resp[1:5])[0]
        offset = 5
        keys: list[tuple[bytes, str]] = []
        for _ in range(nkeys):
            key_blob, offset = _parse_ssh_string(resp, offset)
            _, offset = _parse_ssh_string(resp, offset)
            key_type, _ = _parse_ssh_string(key_blob, 0)
            keys.append((key_blob, key_type.decode("ascii")))

        if not keys:
            raise TokenError(
                "SSH-агент не содержит ключей.\n"
                "Решение:\n"
                "  1. Перезапустите skotty\n"
                "  2. Проверьте: ssh-add -l\n"
                "  3. Должны быть видны ключи Skotty (ECDSA-CERT)"
            )

        data_bytes = string_to_sign.encode("utf-8")
        last_error = None
        for key_blob, key_type in keys:
            payload = _build_ssh_string(key_blob) + _build_ssh_string(data_bytes) + struct.pack(">I", 0)
            sock.sendall(struct.pack(">IB", 1 + len(payload), 13) + payload)
            response_len = struct.unpack(">I", _recv_all(sock, 4))[0]
            response_body = _recv_all(sock, response_len)
            if response_body[0] != 14:
                continue

            sig_blob, _ = _parse_ssh_string(response_body, 1)
            sig_offset = 0
            _, sig_offset = _parse_ssh_string(sig_blob, sig_offset)
            raw_sig, _ = _parse_ssh_string(sig_blob, sig_offset)

            post_data = {
                "grant_type": "ssh_key",
                "client_id": client_id,
                "client_secret": client_secret,
                "login": login,
                "ts": ts,
                "ssh_sign": _b64u_encode(raw_sig),
            }
            if "cert" in key_type:
                post_data["public_cert"] = _b64u_encode(key_blob)

            encoded = parse.urlencode(post_data).encode("utf-8")
            req = request.Request(oauth_url, data=encoded, method="POST")
            req.add_header("Content-Type", "application/x-www-form-urlencoded")
            try:
                with request.urlopen(req, timeout=30) as resp_http:
                    payload_json = json.loads(resp_http.read().decode("utf-8"))
                    token = payload_json.get("access_token", "").strip()
                    if token:
                        return token
                    last_error = str(payload_json)
            except error.HTTPError as e:
                last_error = e.read().decode("utf-8", errors="replace")
            except error.URLError as e:
                raise TokenError(
                    f"Сетевая ошибка при обращении к OAuth-серверу ({oauth_url}): {e.reason}\n"
                    "Решение: проверьте сетевое подключение и доступность oauth.yandex-team.ru"
                ) from e
            except TimeoutError:
                raise TokenError(
                    f"Таймаут при обращении к OAuth-серверу ({oauth_url}).\n"
                    "Решение: проверьте сеть или повторите позже"
                )

        raise TokenError(_parse_oauth_error(last_error or ""))
    except struct.error as e:
        raise TokenError(
            f"Ошибка разбора ответа SSH-агента: {e}\n"
            "Решение: возможно SSH_AUTH_SOCK указывает не на skotty.\n"
            "  Проверьте: echo $SSH_AUTH_SOCK && ssh-add -l"
        ) from e
    finally:
        sock.close()


def resolve_token(
    *,
    client_id: str = DEFAULT_CLIENT_ID,
    client_secret: str = DEFAULT_CLIENT_SECRET,
) -> str:
    """Получить OAuth-токен строго через skotty (SSH-agent)."""
    return get_token_via_ssh(client_id=client_id, client_secret=client_secret)
