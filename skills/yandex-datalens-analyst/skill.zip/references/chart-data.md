# Chart Data API Reference

Endpoint: `POST https://charts.yandex-team.ru/api/run`

This API retrieves the raw data that a chart displays. Useful for extracting data from existing charts programmatically.

## Request

Предпочтительный путь — Skotty-анализатор из корня скилла. Он сам получает актуальный OAuth и применяет параметры таба:

```bash
python3 scripts/analyze.py --run-chart-with-tab-context <DASHBOARD_ID> <CHART_ID>
```

Не используй `DATALENS_OAUTH_TOKEN` и token-файлы. Прямой HTTP-пример ниже показывает только форму API; OAuth для него должен быть получен программно через `scripts/auth_utils.py` и не должен сохраняться.

```bash
curl -X POST 'https://charts.yandex-team.ru/api/run' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "id": "<CHART_ENTRY_ID>",
    "params": {
      "param_name": "param_value"
    }
  }'
```

## Parameters

- `id` (required) — The entry ID of the chart.
- `params` (optional) — Key-value pairs to override chart parameters (e.g., date filters, selectors).

## Response

The response format depends on the chart type. It typically includes:

```json
{
  "data": {
    "graphs": [...],
    "categories": [...],
    "categories_ms": [...]
  },
  "config": {
    "highchartsConfig": {...}
  },
  "sources": {...}
}
```

The exact structure varies by chart type. The response is not guaranteed to be stable — it's intended for data extraction, not as a programmatic API contract.

## Use Cases

- Extracting data from an existing chart for further processing
- Debugging chart data issues
- Building automated reports from chart data
- Passing chart parameters programmatically (e.g., changing date range)

## Example with Parameters

```bash
curl -X POST 'https://charts.yandex-team.ru/api/run' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "id": "abc123def456",
    "params": {
      "date_from": "2024-01-01",
      "date_to": "2024-06-30",
      "region": "RU"
    }
  }'
```
