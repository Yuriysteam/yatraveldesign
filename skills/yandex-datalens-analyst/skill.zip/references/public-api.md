# Public API Reference

Base URL: `https://api.datalens.yandex.net/`

The Public API provides RPC-style methods for managing DataLens objects. All methods use `POST` with JSON body.

**IMPORTANT:** This is the primary API for creating and editing wizard charts. The older Charts API (`api.charts.yandex.net`) does NOT support creating wizard charts.

## Common Headers

```
Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>
x-dl-api-version: 0
Content-Type: application/json
Accept: application/json
```

## Full Endpoint List

| Endpoint | Description |
|----------|-------------|
| `/rpc/createWizardChart` | Create a wizard chart (bar, line, pie, etc.) |
| `/rpc/getWizardChart` | Get wizard chart by ID |
| `/rpc/updateWizardChart` | Update existing wizard chart |
| `/rpc/deleteWizardChart` | Delete wizard chart |
| `/rpc/createEditorChart` | Create an editor (code-based) chart |
| `/rpc/getEditorChart` | Get editor chart by ID |
| `/rpc/updateEditorChart` | Update editor chart |
| `/rpc/deleteEditorChart` | Delete editor chart |
| `/rpc/createQLChart` | Create a QL chart |
| `/rpc/getQLChart` | Get QL chart by ID |
| `/rpc/updateQLChart` | Update QL chart |
| `/rpc/deleteQLChart` | Delete QL chart |
| `/rpc/createDashboard` | Create dashboard |
| `/rpc/getDashboard` | Get dashboard by ID |
| `/rpc/updateDashboard` | Update dashboard |
| `/rpc/deleteDashboard` | Delete dashboard |
| `/rpc/getDataset` | Get dataset |
| `/rpc/createDataset` | Create dataset |
| `/rpc/updateDataset` | Update dataset |
| `/rpc/deleteDataset` | Delete dataset |
| `/rpc/validateDataset` | Validate dataset |
| `/rpc/createConnection` | Create connection |
| `/rpc/getConnection` | Get connection |
| `/rpc/updateConnection` | Update connection |
| `/rpc/deleteConnection` | Delete connection |
| `/rpc/createFolder` | Create folder |
| `/rpc/listDirectory` | List directory contents |
| `/rpc/getEntries` | Get entries with filters |
| `/rpc/getEntriesRelations` | Get related objects |
| `/rpc/getEntriesPermissions` | Get permissions |

---

## Wizard Charts

Wizard charts are the most common chart type in DataLens UI. They include bar, line, pie, area, scatter, treemap, and other visualization types.

### Get Wizard Chart

`POST /rpc/getWizardChart`

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/getWizardChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"chartId": "<ENTRY_ID>"}'
```

Optional parameters:
- `workbookId` — workbook ID (null for folder-based)
- `revId` — specific revision ID
- `branch` — `"saved"` or `"published"`
- `includePermissions` — include permissions info
- `includeLinks` — include linked entries
- `includeFavorite` — include favorite flag

Response structure:
```json
{
  "entryId": "abc123",
  "key": "path/to/chart",
  "type": "graph_wizard_node",
  "revId": "...",
  "data": {
    "shared": "<JSON string with chart config>"
  }
}
```

**IMPORTANT:** The `data.shared` field is a **JSON string** (not an object). You must `JSON.parse()` / `json.loads()` it to read, and `JSON.stringify()` / `json.dumps()` it when writing.

### Create Wizard Chart

`POST /rpc/createWizardChart`

**CRITICAL:** The `data` field must be the shared config object **directly** (not wrapped in `{"shared": "..."}`). The API will serialize it internally.

```bash
# Build the request in Python:
import json
shared_config = {
    "type": "datalens",
    "version": "15",
    "datasetsIds": ["<DATASET_ID>"],
    "visualization": {...},
    ...
}
request = {
    "key": "path/to/new-chart",
    "template": "datalens",
    "data": shared_config  # Pass the object directly, NOT {"shared": json.dumps(shared_config)}
}
```

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/createWizardChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d @request.json
```

Parameters:
- `key` (string) — path in the navigation tree (e.g. `"users/login/charts/my-chart"`)
- `template` (string, required) — always `"datalens"`
- `data` (object, required) — the shared config object directly (visualization, datasetsIds, placeholders, etc.)
- `name` (string, optional) — display name
- `workbookId` (string, optional) — workbook ID
- `annotation` (object, optional) — `{"description": "..."}`

Response contains `entryId`, `key`, `type`, `revId`, and `data.shared` (as a JSON string in the response).

**IMPORTANT:** `createWizardChart` creates the chart as a **draft**. To make it visible in the UI, you must immediately follow up with `updateWizardChart` using `"mode": "publish"` and the same shared config.

### Update Wizard Chart

`POST /rpc/updateWizardChart`

**CRITICAL:** Same as create — `data` is the shared config object directly.

```python
update_request = {
    "entryId": "<ENTRY_ID>",
    "template": "datalens",
    "mode": "publish",
    "data": shared_config  # The shared config object directly
}
```

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/updateWizardChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d @update_request.json
```

Parameters:
- `entryId` (string, required) — chart entry ID
- `template` (string, required) — always `"datalens"`
- `mode` (string, required) — `"save"` (draft) or `"publish"`
- `data` (object, required) — the shared config object directly

### Delete Wizard Chart

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/deleteWizardChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"chartId": "<ENTRY_ID>"}'
```

### Wizard Chart `shared` Config Structure

The `shared` field (after parsing from JSON string) has this structure:

```json
{
  "type": "datalens",
  "version": "15",
  "datasetsIds": ["<DATASET_ID>"],
  "datasetsPartialFields": [[...field definitions...]],
  "visualization": {
    "id": "<VIS_TYPE>",
    "type": "<VIS_TYPE>",
    "placeholders": [...]
  },
  "colors": [],
  "colorsConfig": {},
  "filters": [],
  "sort": [],
  "labels": [],
  "tooltips": [],
  "shapes": [],
  "shapesConfig": {},
  "segments": [],
  "links": [],
  "updates": [],
  "hierarchies": [],
  "geopointsConfig": {},
  "extraSettings": {}
}
```

### Visualization Types

| `id` / `type` | Description | Placeholders |
|----------------|-------------|--------------|
| `line` | Line chart | x, y, colors |
| `area` | Area chart | x, y, colors |
| `area100p` | 100% stacked area | x, y, colors |
| `column` | Vertical bar chart | x, y, colors |
| `column100p` | 100% stacked column | x, y, colors |
| `bar` | Horizontal bar chart | y, x, colors |
| `bar100p` | 100% stacked bar | y, x, colors |
| `pie` | Pie chart | dimensions, colors, measures |
| `donut` | Donut chart | dimensions, colors, measures |
| `scatter` | Scatter plot | x, y, points, colors, size |
| `treemap` | Treemap | dimensions, colors, measures |
| `flatTable` | Flat table (viz `type`=`table`) | flat-table-columns |
| `pivot-table` | Pivot table | pivot-table-columns, pivot-table-rows, measures |
| `metric` | Single metric | measures |

### Placeholder Structure

Each visualization type has specific placeholders. Fields go into placeholder `items`:

**For bar chart (horizontal bars):**
```json
{
  "placeholders": [
    {
      "id": "y",
      "type": "y",
      "title": "section_y",
      "items": [<DIMENSION_FIELD>]
    },
    {
      "id": "x",
      "type": "x",
      "title": "section_x",
      "items": [<MEASURE_FIELD>],
      "settings": {
        "axisModeMap": {"<field_guid>": "continuous"}
      }
    }
  ]
}
```

**For column chart (vertical bars):**
```json
{
  "placeholders": [
    {
      "id": "x",
      "type": "x",
      "title": "section_x",
      "items": [<DIMENSION_FIELD>]
    },
    {
      "id": "y",
      "type": "y",
      "title": "section_y",
      "items": [<MEASURE_FIELD>],
      "settings": {
        "axisModeMap": {"<field_guid>": "continuous"}
      }
    }
  ]
}
```

**For line / area chart:**
```json
{
  "placeholders": [
    {
      "id": "x",
      "type": "x",
      "title": "section_x",
      "items": [<DATETIME_FIELD>]
    },
    {
      "id": "y",
      "type": "y",
      "title": "section_y",
      "items": [<MEASURE_FIELD>]
    }
  ]
}
```

**For pie / donut chart:**
```json
{
  "placeholders": [
    {
      "id": "dimensions",
      "type": "dimensions",
      "title": "section_categories",
      "items": []
    },
    {
      "id": "colors",
      "type": "colors",
      "title": "section_color",
      "items": [<DIMENSION_FIELD>]
    },
    {
      "id": "measures",
      "type": "measures",
      "title": "section_measures",
      "items": [<MEASURE_FIELD>]
    }
  ]
}
```

### Field Definition

A field in a placeholder item looks like:

```json
{
  "title": "my_field",
  "guid": "my_field_abc1",
  "type": "DIMENSION",
  "data_type": "string",
  "initial_data_type": "string",
  "cast": "string",
  "aggregation": "none",
  "source": "column_name",
  "avatar_id": "<avatar_id>",
  "calc_mode": "direct",
  "datasetId": "<DATASET_ID>",
  "valid": true,
  "hidden": false,
  "virtual": false,
  "lock_aggregation": false,
  "aggregation_locked": false,
  "has_auto_aggregation": false,
  "autoaggregated": false,
  "managed_by": "user"
}
```

For a MEASURE field, set `"type": "MEASURE"` and `"aggregation": "sum"` (or `"count"`, `"countunique"`, `"avg"`, etc.).

**Building fields from a dataset**: When creating a new chart from a dataset's fields, the safest approach is to copy all field properties from the `getDataset` response's `result_schema` array. Each field there has `guid`, `title`, `type`, `data_type`, `cast`, `source`, `avatar_id`, `calc_mode`, `aggregation`, `initial_data_type`, etc. — use them as-is in the placeholder items. Missing properties (like `avatar_id` or `calc_mode`) will cause the chart to fail to load the dataset.

Also, you must include `datasetsPartialFields` in the shared config — this is an **array of arrays** (not array of objects). Each inner array contains objects with at least `guid`, `title`, and `calc_mode` for each field used in the chart. Example: `[[{"guid": "...", "title": "...", "calc_mode": "direct"}, ...]]`.

**Important for flat tables (`flatTable`):** Use `"id": "flatTable"` and `"type": "table"` in the visualization config (not `"flat-table"`). Add `"extraSettings": {"pagination": "on", "limit": 100}` to avoid row count limit errors. Only use fields with a valid `avatar_id` (skip formula/parameter fields that have `avatar_id: null`).

### Sort

Add sorting by including field objects in the `sort` array with a `direction` property:

```json
{
  "sort": [
    {
      "...all field properties...",
      "direction": "DESC"
    }
  ]
}
```

### Filters

```json
{
  "filters": [
    {
      "...field properties...",
      "filter": {
        "operation": "EQ",
        "value": ["some_value"]
      }
    }
  ]
}
```

Filter operations: `EQ`, `NE`, `GT`, `GTE`, `LT`, `LTE`, `IN`, `NIN`, `ICONTAINS`, `STARTSWITH`, `ENDSWITH`, `BETWEEN`, `ISNULL`, `ISNOTNULL`

---

## Editor Charts

Editor charts are code-based charts with JavaScript processing. Use these when wizard charts can't do what you need (e.g. custom data transformations, top-N filtering).

### Editor Chart Types

| `type` value | Description | Required data tabs |
|------|-------------|-----------|
| `graph_node` | Highcharts-based chart | shared, params, sources, controls, prepare, statface_graph, graph |
| `d3_node` | Gravity Charts (D3) chart | shared, params, sources, controls, prepare, config |
| `table_node` | Table | shared, params, sources, controls, prepare, config |
| `metric_node` | Metric card | shared, params, sources, prepare, config |
| `timeseries_node` | Yagr time series | shared, params, sources, controls, prepare, config, graph |
| `markdown_node` | Markdown text | shared, params, sources, controls, prepare |
| `control_node` | Selector / filter | shared, params, sources, controls |
| `ymap_node` | Yandex Maps | ymap, shared, params, sources, prepare |
| `markup_node` | Markup | shared, params, sources, prepare, config |

**All data tabs are strings** (not objects).

### Create Editor Chart

`POST /rpc/createEditorChart`

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/createEditorChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{
    "entry": {
      "key": "path/to/chart",
      "type": "graph_node",
      "data": {
        "shared": "",
        "params": "id = <SOURCE_CHART_OR_DATASET_ID>",
        "sources": "src: /api/run",
        "controls": "",
        "prepare": "var data = ChartEditor.getLoadedData();\n// transform data...\nreturn {categories: [...], graphs: [...]};",
        "statface_graph": "",
        "graph": "{\"chart\":{\"type\":\"bar\"}}"
      }
    }
  }'
```

### Get Editor Chart

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/getEditorChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"chartId": "<ENTRY_ID>"}'
```

### Update Editor Chart

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/updateEditorChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{
    "mode": "publish",
    "entry": {
      "entryId": "<ENTRY_ID>",
      "type": "graph_node",
      "data": {
        "shared": "",
        "params": "...",
        "sources": "...",
        "controls": "",
        "prepare": "...",
        "statface_graph": "",
        "graph": "..."
      }
    }
  }'
```

---

## Datasets

### Get Dataset

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/getDataset' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"datasetId": "<DATASET_ID>"}'
```

### Update Dataset

`POST /rpc/updateDataset`

**CRITICAL:** The `data` field must be the **full dataset object** (sources, source_avatars, result_schema, revision_id, etc.). Sending incomplete data will **wipe** the dataset.

```python
# 1. Get current dataset
ds = get_dataset(dataset_id)
dataset = ds["dataset"]

# 2. Modify fields
for f in dataset["result_schema"]:
    if f["title"] == "my_field":
        f["type"] = "MEASURE"
        f["aggregation"] = "sum"

# 3. Send full dataset object as "data"
update_request = {
    "datasetId": "<DATASET_ID>",
    "data": dataset  # Must include revision_id for optimistic locking
}
# POST /rpc/updateDataset
```

Parameters:
- `datasetId` (string, required) — dataset ID
- `data` (object, required) — **full** dataset object including `revision_id`, `sources`, `source_avatars`, `result_schema`

### Create Dataset (CHYT — two-step process)

`/rpc/createDataset` through Public API does NOT work for CHYT sources (returns 500/403). Use the validate + gateway pattern instead.

**Step 1:** `POST /rpc/validateDataset` (Public API) — the DS API reads the table schema from CHYT automatically.

```python
import uuid

ds_uuid = str(uuid.uuid4())
param_hash = uuid.uuid4().hex[:16]

validate_body = {
    "datasetId": "",
    "workbookId": None,
    "data": {
        "dataset": {
            "sources": [], "source_avatars": [], "result_schema": [],
            "result_schema_aux": {"inter_dependencies": {"deps": []}},
            "rls": {}, "rls2": {}, "obligatory_filters": [], "avatar_relations": [],
            "revision_id": None, "preview_enabled": True, "load_preview_by_default": True,
            "data_export_forbidden": False, "template_enabled": False,
            "component_errors": {"items": []}, "description": "",
        },
        "updates": [
            {
                "action": "add_source",
                "source": {
                    "id": ds_uuid, "title": "my_table", "group": [],
                    "source_type": "CHYT_TABLE",
                    "connection_id": "<CONNECTION_ID>",
                    "parameters": {"table_name": "//path/to/yt/table"},
                    "tab_title": "Таблица",
                    "form": [{"name": "table_name", "input_type": "text", "default": "",
                              "required": True, "title": "Путь к таблице в YT",
                              "field_doc_key": "CHYT_TABLE/table_name", "template_enabled": False}],
                    "disabled": False, "parameter_hash": param_hash,
                },
            },
            {
                "action": "add_source_avatar",
                "source_avatar": {"id": ds_uuid, "is_root": True, "title": "my_table", "source_id": ds_uuid},
            },
        ],
    },
}
# Response contains full dataset with auto-detected result_schema
```

**Step 2:** `POST https://datalens.yandex-team.ru/gateway/root/bi/createDataset` (Gateway API, NOT Public API)

```python
# Optionally modify validated result (e.g., set numeric fields to MEASURE)
validated = validate_response["dataset"]
for f in validated["result_schema"]:
    if f["data_type"] == "float":
        f["type"] = "MEASURE"
        f["aggregation"] = "sum"

create_body = {
    "dataset": validated,  # Full dataset object from validateDataset
    "dir_path": "folder/path/in/datalens",
    "name": "dataset_name",
}
# Response: {"id": "<DATASET_ID>", ...}
```

Gateway API (`datalens.yandex-team.ru/gateway/root/bi/`) uses standard auth headers but does NOT require `x-dl-api-version`.

Reference implementation: `trunk:fintech/fdt/fbi/automation/libs/datalens/dl_wrapper.py`

### Validate Dataset

`POST /rpc/validateDataset`

Used in the dataset creation flow above. Also useful for adding fields to existing datasets:

```python
validate_body = {
    "datasetId": "<EXISTING_DATASET_ID>",  # empty string for new datasets
    "data": {
        "dataset": existing_dataset_object,
        "updates": [
            {"action": "add_field", "field": {"title": "new_field", "formula": "SUM([amount])", ...}},
        ],
    },
}
```

### Get Entries Relations

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/getEntriesRelations' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"entryIds": ["<ENTRY_ID>"]}'
```

### List Directory

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/listDirectory' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"path": "users/mylogin/charts"}'
```

---

## Dataset Structure

A dataset response contains:

```json
{
  "id": "g5p0l0qrijfy1",
  "key": "Users/login/path/to/dataset",
  "dataset": {
    "result_schema": [
      {
        "guid": "field_guid_abc1",
        "title": "Display Name",
        "description": "",
        "type": "DIMENSION",
        "data_type": "string",
        "initial_data_type": "string",
        "cast": "string",
        "aggregation": "none",
        "calc_mode": "direct",
        "source": "column_name",
        "avatar_id": "avatar-uuid",
        "hidden": false,
        "virtual": false,
        "valid": true,
        "managed_by": "user",
        "formula": "",
        "guid_formula": "",
        "has_auto_aggregation": false,
        "lock_aggregation": false,
        "aggregation_locked": false,
        "autoaggregated": false
      }
    ],
    "source_avatars": [
      {
        "id": "avatar-uuid",
        "source_id": "source_id",
        "title": "Source Name"
      }
    ],
    "sources": [
      {
        "id": "source_id",
        "title": "Source Name",
        "connection_ref": "<CONNECTION_ID>",
        "spec": {
          "kind": "sql_table",
          "table_name": "my_table",
          "db_name": "my_database"
        }
      }
    ]
  }
}
```

**IMPORTANT:** Use `dataset.result_schema` (not `dataset.fields`) to get the full list of fields with all properties needed for chart creation. Fields without `avatar_id` are formula/parameter fields — they work in charts but require special handling.
```

## Field Data Types (`cast`)

| Type | Description |
|------|-------------|
| `string` | Text |
| `integer` | Integer number |
| `float` | Floating point |
| `date` | Date (YYYY-MM-DD) |
| `datetime` | Date + time |
| `datetimetz` | Date + time with timezone |
| `boolean` | True/false |
| `geopoint` | Geographic point |
| `geopolygon` | Geographic polygon |
| `uuid` | UUID |
| `markup` | Markup text |
| `array_str` | Array of strings |
| `array_int` | Array of integers |
| `array_float` | Array of floats |
| `tree_str` | Tree structure |

## Aggregation Types

| Type | Description |
|------|-------------|
| `none` | No aggregation |
| `sum` | Sum |
| `avg` | Average |
| `min` | Minimum |
| `max` | Maximum |
| `count` | Count |
| `countunique` | Count distinct |

## Data Source Spec Types

| Kind | Description |
|------|-------------|
| `sql_table` | Direct table reference |
| `sql_table_in_schema` | Table with schema prefix |
| `sql_query` | SQL subquery as source |
| `chyt_table_list` | CHYT table list |
| `chyt_table_range` | CHYT table range |

## Connection Types

| Type | Description |
|------|-------------|
| `ch_over_yt` | ClickHouse over YT (system auth) |
| `ch_over_yt_user_auth` | ClickHouse over YT (user auth) |
| `clickhouse` | Direct ClickHouse |
| `postgres` | PostgreSQL |
