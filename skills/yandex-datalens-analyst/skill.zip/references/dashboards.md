# Dashboards API Reference

Base URL: `https://api.dash.yandex.net/v1/`

## Endpoints

### Create Dashboard
`POST /dashboards`

### Read Dashboard
`GET /dashboards/<ENTRY_ID>`

Query parameters:
- `?branch=published` — get the published version
- `?revId=<REVISION_ID>` — get a specific revision
- No parameters — get the latest draft

### Update Dashboard
`POST /dashboards/<ENTRY_ID>`

### Delete Dashboard
Use Public API.

## Dashboard Schema

```json
{
  "key": "users/<login>/dashboards/my-dashboard",
  "mode": "publish",
  "data": {
    "tabs": [
      {
        "id": "tab-1",
        "title": "Main Tab",
        "items": [],
        "layout": [],
        "connections": [],
        "aliases": {
          "default": []
        }
      }
    ]
  }
}
```

## Tab Items

### Title Item
```json
{
  "id": "title-1",
  "type": "title",
  "data": {
    "text": "Section Title",
    "size": "l"
  },
  "defaults": {}
}
```

Sizes: `"l"` (large), `"m"` (medium), `"s"` (small)

### Text Item
```json
{
  "id": "text-1",
  "type": "text",
  "data": {
    "text": "Some description text with **markdown** support"
  },
  "defaults": {}
}
```

### Widget Item (Chart)
```json
{
  "id": "widget-1",
  "type": "widget",
  "data": {
    "tabs": [
      {
        "id": "widget-tab-1",
        "title": "Chart Title",
        "chartId": "<CHART_ENTRY_ID>",
        "params": {}
      }
    ]
  },
  "defaults": {}
}
```

A widget can have multiple tabs — each tab references a different chart.

### Control Item (Selector / Filter)

#### Dataset-based selector
```json
{
  "id": "control-1",
  "type": "control",
  "data": {
    "sourceType": "dataset",
    "datasetId": "<DATASET_ID>",
    "datasetFieldId": "<FIELD_ID>",
    "fieldName": "field_name",
    "elementType": "select",
    "multiselectable": true,
    "isRange": false,
    "defaults": ["value1", "value2"]
  },
  "defaults": {
    "field_name": ["value1", "value2"]
  }
}
```

#### Manual selector
```json
{
  "id": "control-2",
  "type": "control",
  "data": {
    "sourceType": "manual",
    "elementType": "select",
    "fieldName": "my_param",
    "title": "Choose option",
    "multiselectable": false,
    "acceptableValues": [
      {"title": "Option A", "value": "a"},
      {"title": "Option B", "value": "b"}
    ],
    "defaults": ["a"]
  },
  "defaults": {
    "my_param": ["a"]
  }
}
```

#### Date selector
```json
{
  "id": "control-3",
  "type": "control",
  "data": {
    "sourceType": "manual",
    "elementType": "date",
    "fieldName": "date_param",
    "title": "Select date",
    "defaults": ["2024-01-01"]
  },
  "defaults": {
    "date_param": ["2024-01-01"]
  }
}
```

#### Date range selector
```json
{
  "id": "control-4",
  "type": "control",
  "data": {
    "sourceType": "manual",
    "elementType": "daterange",
    "fieldName": "daterange_param",
    "title": "Date range",
    "defaults": ["2024-01-01", "2024-12-31"]
  },
  "defaults": {
    "daterange_param": ["2024-01-01", "2024-12-31"]
  }
}
```

#### External selector (from another chart)
```json
{
  "id": "control-5",
  "type": "control",
  "data": {
    "sourceType": "external",
    "chartId": "<SELECTOR_CHART_ID>"
  },
  "defaults": {}
}
```

## Layout

The grid is **36 columns** wide. Each height unit = **18px**.

Each item in `layout` corresponds to an item in `items` by `i` (ID):

```json
{
  "layout": [
    {"i": "title-1", "h": 2, "w": 36, "x": 0, "y": 0},
    {"i": "widget-1", "h": 16, "w": 18, "x": 0, "y": 2},
    {"i": "widget-2", "h": 16, "w": 18, "x": 18, "y": 2},
    {"i": "control-1", "h": 2, "w": 8, "x": 0, "y": 18}
  ]
}
```

Typical heights:
- Title: `h: 2`
- Selector / control: `h: 2`
- Chart widget: `h: 12-20`

## Connections

Connections define how selectors filter charts:

```json
{
  "connections": [
    {
      "from": "control-1",
      "to": "widget-1",
      "kind": "ignore"
    }
  ]
}
```

Kinds:
- `"ignore"` — the widget ignores this control
- By default (no connection entry), controls affect all widgets via matching parameter names.

## Aliases

Aliases map parameter names across different charts/datasets so that selectors work correctly:

```json
{
  "aliases": {
    "default": [
      ["field_name_in_dataset_1", "field_name_in_dataset_2"]
    ]
  }
}
```

## Versioning

- `"mode": "publish"` — publishes immediately
- `"mode": "save"` — saves as draft
- Default is `"publish"`

## Full Dashboard Example

```json
{
  "key": "users/mylogin/dashboards/sales-overview",
  "mode": "publish",
  "data": {
    "tabs": [
      {
        "id": "main",
        "title": "Sales Overview",
        "items": [
          {
            "id": "title-1",
            "type": "title",
            "data": {"text": "Sales Dashboard", "size": "l"},
            "defaults": {}
          },
          {
            "id": "date-filter",
            "type": "control",
            "data": {
              "sourceType": "manual",
              "elementType": "daterange",
              "fieldName": "date",
              "title": "Period",
              "defaults": ["2024-01-01", "2024-12-31"]
            },
            "defaults": {"date": ["2024-01-01", "2024-12-31"]}
          },
          {
            "id": "revenue-chart",
            "type": "widget",
            "data": {
              "tabs": [
                {
                  "id": "rev-tab",
                  "title": "Revenue",
                  "chartId": "abc123",
                  "params": {}
                }
              ]
            },
            "defaults": {}
          }
        ],
        "layout": [
          {"i": "title-1", "h": 2, "w": 36, "x": 0, "y": 0},
          {"i": "date-filter", "h": 2, "w": 10, "x": 0, "y": 2},
          {"i": "revenue-chart", "h": 16, "w": 36, "x": 0, "y": 4}
        ],
        "connections": [],
        "aliases": {"default": []}
      }
    ]
  }
}
```
