# Screenshots API Reference

Endpoint: `POST https://charts.yandex-team.ru/api/scr/v1/screenshots`

Generates PNG screenshots of charts. Useful for automated reports, notifications, and embedding chart images.

## Request

Content-Type: `application/x-www-form-urlencoded`

```bash
curl -X POST 'https://charts.yandex-team.ru/api/scr/v1/screenshots' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'path=%2Fpreview%2Feditor%2F<CHART_ID>%3F_embedded%3D1&width=800&height=600'
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `path` | Yes | URL path to the chart, must include `_embedded=1`. Must be URL-encoded. |
| `width` | No | Image width in pixels |
| `height` | No | Image height in pixels |
| `base64` | No | Set to `"1"` to return base64-encoded image instead of binary PNG |
| `type` | No | Set to `"table"` for table-type chart screenshots |

## Path Format

The `path` parameter is the URL path portion of the chart URL, with `_embedded=1` appended:

```
/preview/editor/<CHART_ID>?_embedded=1
```

This must be URL-encoded:
```
%2Fpreview%2Feditor%2F<CHART_ID>%3F_embedded%3D1
```

## With Parameters

To pass chart parameters (e.g., date filters), add them to the path:

```
/preview/editor/<CHART_ID>?_embedded=1&date_from=2024-01-01&date_to=2024-06-30
```

URL-encoded:
```
%2Fpreview%2Feditor%2F<CHART_ID>%3F_embedded%3D1%26date_from%3D2024-01-01%26date_to%3D2024-06-30
```

## Response

- Without `base64=1`: Binary PNG image data
- With `base64=1`: Base64-encoded string of the PNG image

## Example: Save Screenshot to File

```bash
curl -X POST 'https://charts.yandex-team.ru/api/scr/v1/screenshots' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'path=%2Fpreview%2Feditor%2Fabc123%3F_embedded%3D1&width=1200&height=800' \
  -o chart_screenshot.png
```

## Example: Get Base64

```bash
curl -X POST 'https://charts.yandex-team.ru/api/scr/v1/screenshots' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'path=%2Fpreview%2Feditor%2Fabc123%3F_embedded%3D1&width=800&height=600&base64=1'
```
