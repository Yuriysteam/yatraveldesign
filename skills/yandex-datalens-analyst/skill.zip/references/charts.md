# Charts API Reference

**NOTE:** This is the LEGACY Charts API. For creating and editing wizard charts, use the Public API (`api.datalens.yandex.net`) — see `references/public-api.md`. This API only supports editor (code-based) charts.

Base URL: `https://api.charts.yandex.net/v1/`

## Endpoints

### Read Chart by ID
`GET /charts/<ENTRY_ID>`

Works for both wizard and editor charts. Returns metadata and data.

### Read Chart by Key
`GET /charts/entryByKey?key=<KEY_PATH>`

### Create Editor Chart
`POST /charts`

**IMPORTANT:** This only works for editor charts (code-based). For wizard charts, use Public API `/rpc/createWizardChart`.

### Update Editor Chart
`POST /charts/<ENTRY_ID>` (legacy) or `PUT /charts/<ENTRY_ID>`

### Delete Chart
Use Public API method `/rpc/deleteEditorChart` or `/rpc/deleteWizardChart`.

## Editor Chart Types and Required Tabs

All `data` values are **strings** containing JavaScript code (`module.exports = {...}`).

| Type | Required tabs in `data` | Type-specific tab |
|------|------------------------|-------------------|
| `graph_node` | sources, params, prepare, controls, shared, statface_graph | `graph` |
| `table_node` | sources, params, prepare, controls, shared | `config` |
| `control_node` | sources, params, prepare, controls, shared | — |
| `markdown_node` | sources, params, prepare, shared | — |
| `metric_node` | sources, params, prepare | `statface_metric` |
| `ymap_node` | sources, params, prepare, shared | `ymap` |
| `module` | prepare | `documentation_ru`, `documentation_en` |

## Editor Chart Tab Descriptions

- **sources** — data source definitions (returns Dataset or array objects)
- **params** — chart parameters (arrays of default values)
- **prepare** — data transformation code, uses `ChartEditor.getLoadedData()`, `ChartEditor.getParams()`, etc.
- **controls** — control elements (select, radio, checkbox, slider, date, text)
- **graph** — Highcharts configuration (for `graph_node`)
- **config** — table column config (for `table_node`)
- **statface_graph** — legacy graph config (for `graph_node`, usually empty string)
- **statface_metric** — metric display config (for `metric_node`)
- **ymap** — Yandex Maps config (for `ymap_node`)
- **shared** — shared constants and data (JSON string)

## Create Editor Chart Example (via Public API — PREFERRED)

```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/createEditorChart' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{
    "entry": {
      "key": "path/to/chart",
      "type": "graph_node",
      "data": {
        "sources": "module.exports = {source1: {url: \"/api/run\", method: \"POST\", data: {id: \"<CHART_OR_DATASET_ID>\", params: {}}}}",
        "params": "module.exports = {}",
        "prepare": "var data = ChartEditor.getLoadedData();\nvar src = data.source1;\n// transform...\nreturn {categories: [...], graphs: [...]};",
        "controls": "module.exports = {}",
        "graph": "module.exports = {chart: {type: \"bar\"}, legend: {enabled: false}}",
        "statface_graph": "",
        "shared": "{}"
      }
    }
  }'
```

## Create Editor Chart Example (via Legacy API)

```bash
curl -X POST 'https://api.charts.yandex.net/v1/charts' \
  -H "Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>" \
  -H 'Content-Type: application/json' \
  -k \
  -d '{
    "key": "path/to/chart",
    "type": "graph_node",
    "mode": "publish",
    "data": {
      "sources": "module.exports = {...}",
      "params": "module.exports = {...}",
      "prepare": "module.exports = function(args) {...}",
      "controls": "module.exports = {...}",
      "graph": "module.exports = {...}",
      "statface_graph": "",
      "shared": "{}"
    }
  }'
```

## ChartEditor API (available in prepare.ts)

```javascript
var data = ChartEditor.getLoadedData();  // Get data from sources
var params = ChartEditor.getParams();     // Get current parameters
ChartEditor.updateParams({key: value});   // Update parameters
var tab = ChartEditor.getTab();           // Get current tab
ChartEditor.setTab(tabName);              // Switch tab
```

## Modes

- `"publish"` — Saves and publishes immediately (default)
- `"save"` — Saves as draft without publishing

## Limitations

- Max request size: 10 MB
- Rate limit: 100 requests per minute
