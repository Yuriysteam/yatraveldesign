# Comments API Reference

Base endpoint: `https://charts.yandex-team.ru/api/v1/comments`

Manages annotations and comments on charts — vertical lines, shaded bands, flags, and point markers.

**IMPORTANT:** Comments/annotations are only visible on **editor charts** (`graph_node`, `d3_node`, etc.) and editor charts embedded in dashboards. They are **not visible** on wizard charts (`graph_wizard_node`). If the user wants to annotate a wizard chart, warn them that annotations won't be displayed — they need an editor chart for this feature.

## Comment Types

| Type | Description | Visual |
|------|-------------|--------|
| `line-x` | Vertical line at a point in time | `│` |
| `band-x` | Shaded band between two dates | `█████` |
| `flag-x` | Flag annotation at a point | `⚑` |
| `dot-x-y` | Point marker on a specific data point | `●` |

## Create Comment

`POST /api/v1/comments`

```bash
curl -X POST 'https://charts.yandex-team.ru/api/v1/comments' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "feed": "channel_name",
    "date": "2024-06-15T00:00:00.000Z",
    "type": "line-x",
    "text": "Release v2.0",
    "meta": {
      "color": "#ff0000",
      "dashStyle": "solid",
      "width": 2
    }
  }'
```

## Get Comments (by Feed)

`GET /api/v1/comments?feed=<FEED_NAME>`

```bash
curl -X GET 'https://charts.yandex-team.ru/api/v1/comments?feed=my_channel' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>'
```

## Update Comment

`PUT /api/v1/comments/<COMMENT_ID>`

```bash
curl -X PUT 'https://charts.yandex-team.ru/api/v1/comments/12345' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "text": "Updated annotation text",
    "meta": {"color": "#00ff00"}
  }'
```

## Delete Comment

`DELETE /api/v1/comments/<COMMENT_ID>`

```bash
curl -X DELETE 'https://charts.yandex-team.ru/api/v1/comments/12345' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>'
```

## Delete Entire Feed

`DELETE /api/v1/comments/feed?feed=<FEED_NAME>`

```bash
curl -X DELETE 'https://charts.yandex-team.ru/api/v1/comments/feed?feed=my_channel' \
  -H 'Authorization: OAuth <SKOTTY_RESOLVED_TOKEN>'
```

## Comment Fields

### Common Fields

| Field | Required | Description |
|-------|----------|-------------|
| `feed` | Yes | Channel/feed identifier |
| `date` | Yes | ISO 8601 timestamp |
| `type` | Yes | Comment type (see table above) |
| `text` | Yes | Annotation text |
| `meta` | Yes | Style metadata (see below) |
| `params` | No | Filter parameters |
| `dateUntil` | Only for `band-x` | End date for band |

### Meta Properties by Type

**All types:**
- `color` — Hex color (default: `#ffcc00`)

**line-x:**
- `dashStyle` — Line style: `solid`, `dash`, `dot`, etc. (default: `solid`)
- `width` — Line width in px (default: `2`)

**band-x:**
- `visible` — Show label (default: `false`)
- `zIndex` — Layer order (default: `0`)

**flag-x:**
- `y` — Vertical offset in px (default: `-30`)
- `shape` — Flag shape: `circlepin`, `squarepin`, `flag` (default: `circlepin`)

**dot-x-y:**
- `graphId` — ID of the series to attach to
- `visible` — Show label (default: `true`)
- `fillColor` — Marker fill color
- `textColor` — Label text color

## Examples

### Vertical Line (Release Marker)
```json
{
  "feed": "releases",
  "date": "2024-03-15T12:00:00.000Z",
  "type": "line-x",
  "text": "v3.0 Release",
  "meta": {
    "color": "#e74c3c",
    "dashStyle": "dash",
    "width": 2
  }
}
```

### Shaded Band (Maintenance Window)
```json
{
  "feed": "maintenance",
  "date": "2024-03-20T02:00:00.000Z",
  "dateUntil": "2024-03-20T06:00:00.000Z",
  "type": "band-x",
  "text": "Planned maintenance",
  "meta": {
    "color": "#f39c12",
    "visible": true
  }
}
```

### Flag Annotation
```json
{
  "feed": "events",
  "date": "2024-04-01T00:00:00.000Z",
  "type": "flag-x",
  "text": "Marketing campaign start",
  "meta": {
    "color": "#2ecc71",
    "shape": "flag",
    "y": -40
  }
}
```
