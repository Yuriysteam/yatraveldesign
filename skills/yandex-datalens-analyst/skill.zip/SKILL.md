---
name: yandex-datalens-analyst
description: "Работа с Yandex DataLens — дашборды, чарты, датасеты, подключения, скриншоты и комментарии через REST API. Триггерные фразы: datalens, дашборд, чарт, график, датасет, визуализация, скриншот дашборда. Используй этот скилл когда пользователь хочет: посмотреть/проанализировать дашборд или чарт; сделать скриншот дашборда или чарта; создать/изменить/удалить wizard-чарт, editor-чарт, датасет или дашборд; извлечь данные из чарта; добавить аннотацию/комментарий к чарту; узнать структуру дашборда (табы, виджеты, селекторы); работать с DataLens API программно. Триггерь при любом упоминании: DataLens, datalens, дашборд (в контексте визуализации), чарт, график в DataLens, таблица в DataLens, скриншот дашборда, визуализация данных, посмотри дашборд, что на дашборде, charts.yandex-team.ru, api.charts.yandex.net, datalens.yandex-team.ru, датасет DataLens, подключение DataLens. НЕ использовать для: YQL-запросов (скилл yql), работы с YT-таблицами (скилл yt), работы с Трекером (скилл tracker)."
allowed-tools: Bash, Read, Write, Edit
---

## Установка

1. Распакуй директорию скилла в папку скилов текущего агента, сохранив `scripts/` и `references/` рядом с `SKILL.md`.
2. Авторизация: строго skotty (OAuth через SSH-agent). Убедись, что skotty запущен и `SSH_AUTH_SOCK` задан.
3. Передай параметры OAuth-приложения через `DATALENS_OAUTH_CLIENT_ID` и `DATALENS_OAUTH_CLIENT_SECRET`. Не записывай их в файлы скилла или Git.

Отдельный OAuth-токен получать, сохранять в файл или передавать через переменную окружения запрещено: авторизация выполняется только через Skotty.

Работа с Yandex DataLens через API. Запрос пользователя: $ARGUMENTS

**КРИТИЧЕСКИ ВАЖНО:** Если что-то не работает (API возвращает 403/404/500, формат не принимается, чарт не рендерится) — НЕ перебирай варианты вслепую и НЕ спрашивай пользователя. СНАЧАЛА прочитай этот скилл целиком и справочники. Ответ почти всегда есть в документации. Слепой перебор API — трата времени.

## Общие принципы

- Запросы к API через `curl` в Bash — показывать команду перед выполнением.
- Внутренняя среда Яндекса: OAuth-токен, домены `*.yandex-team.ru` / `*.yandex.net`.
- TLS: используй системное или корпоративное доверенное хранилище сертификатов. Не отключай проверку сертификатов.
- Предпочитай локальные Python-скрипты `scripts/analyze.py` и `scripts/chart_ops.py`: они получают OAuth-токен автоматически через skotty (SSH-agent).

## Авторизация: строго skotty (OAuth через SSH-agent)

Скрипты `scripts/analyze.py` и `scripts/chart_ops.py` получают OAuth-токен исключительно через SSH-agent (skotty).

**Никогда не используй `DATALENS_OAUTH_TOKEN`, token-файлы или другие копии analyzer.** Даже если переменная окружения задана, запускай скрипты только из директории этого скилла: они самостоятельно получают актуальный OAuth через Skotty.

Требования:
- skotty запущен
- `SSH_AUTH_SOCK` задан
- в агенте есть SSH-ключи

Проверка:
```bash
echo $SSH_AUTH_SOCK
ssh-add -l
python3 scripts/analyze.py --help >/dev/null
```

Для данных чарта всегда используй контекст таба, если известен dashboard id:

```bash
python3 scripts/analyze.py --run-chart-with-tab-context <DASHBOARD_ID> <CHART_ID>
```

Прямой `--run-chart` без контекста допустим только для диагностики: без дефолтных селекторов результат может отличаться от дашборда.

Скрипты реализуют полный цикл авторизации через skotty:
- подключаются к SSH-agent через `SSH_AUTH_SOCK`
- подписывают challenge SSH-ключом
- обменивают подпись на OAuth-токен через `https://oauth.yandex-team.ru/token`

## Аутентификация

Заголовок для всех запросов:
```
Authorization: OAuth <resolved token>
Content-Type: application/json
Accept: application/json
```

## Справочник API

**Public API — основной для создания/редактирования чартов и дашбордов.** Старый Charts API — только для чтения.

| API | Base URL | Справочник | Назначение |
|-----|----------|------------|------------|
| **Public API** | `https://api.datalens.yandex.net/` | `references/public-api.md` | **Создание/редактирование wizard- и editor-чартов, дашбордов, подключений; валидация датасетов** |
| **Gateway API** | `https://datalens.yandex-team.ru/gateway/root/bi/` | `references/public-api.md` | **Создание датасетов** (двухшаговый процесс, см. reference) |
| Dashboards | `https://api.dash.yandex.net/v1/` | `references/dashboards.md` | Чтение структуры дашборда |
| Chart Data | `https://charts.yandex-team.ru/api/run` | `references/chart-data.md` | Извлечение данных чарта |
| Screenshots | `https://charts.yandex-team.ru/api/scr/v1/screenshots` | `references/screenshots.md` | Скриншоты чартов и дашбордов |
| Comments | `https://charts.yandex-team.ru/api/v1/comments` | `references/comments.md` | Комментарии/аннотации к чартам |
| Charts (legacy) | `https://api.charts.yandex.net/v1/` | `references/charts.md` | Чтение метаданных чартов (legacy, не может создавать wizard-чарты) |

**ВАЖНО:** Public API (`api.datalens.yandex.net`) требует заголовок `x-dl-api-version: 0`.

При работе с конкретным API — сначала прочитай соответствующий reference-файл для полной схемы запроса.

## Подключение CHYT

Подключение команды (ID, клика, папка) — в CLAUDE.md проекта. **Всегда использовать существующее подключение — НЕ создавать новые.**

При создании датасетов указывать `connection_id` из CLAUDE.md. При создании QL-чартов: `connection.entryId` оттуда же.

## Подключение PostgreSQL (MDB)

### Создание подключения

```python
# POST https://api.datalens.yandex.net/rpc/createConnection
body = {
    "name": "My PostgreSQL",           # display name (NOT "title")
    "type": "postgres",                 # connection type
    "host": "sas-xxx.db.yandex.net",    # MDB host
    "port": 6432,                       # pgbouncer port
    "db_name": "my_database",           # database name (NOT "dbName")
    "username": "user",
    "password": "<пароль-из-защищённого-хранилища>",
    "ssl_enable": "on",                 # STRING, not boolean! "on"/"off"
    "raw_sql_level": "dashsql",         # enables SQL queries via dashsql
    "dir_path": "Users/login",          # DataLens folder to save connection
}
# Response: {"id": "connection_id"}
```

**Критические нюансы:**
- `ssl_enable` — строка `"on"`, НЕ boolean `true`. Boolean вернёт `"Not a valid boolean."`
- `raw_sql_level: "dashsql"` — без этого `run-sql` через `chart_ops.py` не работает (по умолчанию `"off"`)
- `name` — обязательное поле. НЕ `title`.
- `db_name` — НЕ `dbName`
- `dir_path` — папка в DataLens (например `"Users/login"`), без неё 403

### Обновление подключения

**`updateConnection` имеет ДРУГУЮ схему полей** — не принимает `name`, `type`, `host` и другие поля из create. На практике проще удалить и создать заново:

```python
# DELETE
# POST /rpc/deleteConnection {"connectionId": "<ID>"}
# CREATE заново с новыми параметрами
```

### Prerequisite: сетевой доступ (Puncher)

Для MDB-подключений DataLens должен иметь сетевой доступ к базе. Без puncher-правила — таймаут при любых запросах.

Puncher-правило:
- **Источник:** `_DATALENS_PROD_NETS_`
- **Назначение:** конкретные MDB-хосты (например `sas-xxx.db.yandex.net`, `vla-yyy.db.yandex.net`)
- **Протокол:** TCP
- **Порт:** 6432

Правило требует подтверждения — может занять время.

## Порядок работы

### Шаг 0: Проверить skotty (ПЕРВЫМ ДЕЛОМ)

```bash
echo "${SSH_AUTH_SOCK:+skotty_available}"
ssh-add -l
```

Если skotty недоступен:
- предложи пользователю запустить skotty
- проверить что `SSH_AUTH_SOCK` задан

### Шаги 1–6: Выполнение запроса

1. **Определить операцию** — какой API и метод нужен
2. **Прочитать reference-файл** для этого API — точный формат запроса
3. **Собрать curl-команду** с правильными заголовками, эндпоинтом и JSON-телом
4. **Показать команду** пользователю
5. **Выполнить** через Bash
6. **Разобрать ответ и представить в человекочитаемом виде** — никогда не показывать сырой JSON. Подробности в разделе «Представление результатов»

## Представление результатов

Пользователю нужно понимание, а не JSON. Правила:

### Операции записи (создание/обновление/удаление)

После создания или изменения объекта — всегда показывать кликабельную ссылку:
- **Wizard-чарты:** `https://datalens.yandex-team.ru/wizard/<entryId>`
- **Editor-чарты:** `https://datalens.yandex-team.ru/editor/<entryId>`
- **Дашборды:** `https://datalens.yandex-team.ru/<entryId>`
- **Датасеты:** `https://datalens.yandex-team.ru/datasets/<entryId>`

Кратко описать что сделано: «Создан чарт «Название» → https://datalens.yandex-team.ru/wizard/abc123»

### Структура дашборда

Описывать как человек: перечислить табы по названиям, какие виджеты (чарты) на каждом табе с заголовками, какие селекторы/фильтры доступны. Для селекторов: название, тип (select, date, daterange), мультиселект, дефолтные значения. Не выводить сырой JSON.

### Данные чарта

Не показывать отдельные точки. Давать человекочитаемое описание: что показывает чарт, что на осях, сколько серий данных, диапазоны значений (min/max/avg), тренды (рост, спад, сезонность, выбросы). Цель — пользователь понимает чарт, не глядя на него.

### Типы чартов

Переводить внутренние типы в понятные категории. Не упоминать «wizard» или «editor» — пользователю важно, как выглядит чарт:
- `graph_wizard_node`, `graph_node` → График (линейный, столбчатый, barplot, scatter)
- `d3_wizard_node`, `d3_node` → Круговая диаграмма / treemap
- `table_wizard_node`, `table_node` → Таблица
- `metric_wizard_node`, `metric_node` → Метрика (карточка с числом)
- `timeseries_node` → Таймсерия
- `markdown_node` → Текстовый блок
- `control_node` → Селектор
- `ymap_node` → Карта

### Скриншоты дашбордов

Дашборд может иметь несколько табов. Если пользователь просит «скриншот дашборда» — сначала проверить количество табов. Если их несколько — спросить какой нужен или предложить сделать все. Для каждого таба добавить параметр таба в URL.

**Важно: дашборды обычно длинные.** Дефолтная высота 600–800px обрежет контент. Использовать `height=3000` (или больше) для полной страницы. Ширина 1200 подходит. Для отдельных чартов хватает 800x600.

## Быстрый справочник: частые операции

### Создать Wizard-чарт (Public API — основной способ)

**Двухшаговый процесс: создать → опубликовать.** Чарты создаются как черновики и должны быть опубликованы.

```python
# Шаг 1: Создать (возвращает черновик)
create_request = {
    "key": "path/to/chart",
    "template": "datalens",
    "data": shared_config  # Объект конфига напрямую, НЕ {"shared": "..."}
}
# POST /rpc/createWizardChart → получить entryId

# Шаг 2: Опубликовать (делает видимым в UI)
publish_request = {
    "entryId": "<entryId из шага 1>",
    "template": "datalens",
    "mode": "publish",
    "data": shared_config  # Тот же объект конфига
}
# POST /rpc/updateWizardChart
```

**При ошибке `ENTRY_ALREADY_EXISTS`** — добавить уникальный суффикс (например, timestamp) к ключу, или удалить существующий entry.

### Обновить Wizard-чарт (Public API)
```python
update_request = {
    "entryId": "<ID>",
    "template": "datalens",
    "mode": "publish",
    "data": shared_config  # Объект конфига напрямую, НЕ {"shared": "..."}
}
# POST /rpc/updateWizardChart
```

### Получить Wizard-чарт (Public API)
```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/getWizardChart' \
  -H "Authorization: OAuth $TOKEN" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"chartId": "<ENTRY_ID>"}'
```

### Получить дашборд
```bash
curl -X GET 'https://api.dash.yandex.net/v1/dashboards/<ENTRY_ID>' \
  -H "Authorization: OAuth $TOKEN" \
  -k
```

### Сделать скриншот
```bash
# Дашборд — большая высота, чтобы не обрезать:
curl -X POST 'https://charts.yandex-team.ru/api/scr/v1/screenshots' \
  -H "Authorization: OAuth $TOKEN" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -k \
  -d 'path=%2F<DASHBOARD_SLUG>%3F_embedded%3D1&width=1200&height=3000'

# Отдельный чарт — стандартный размер:
curl -X POST 'https://charts.yandex-team.ru/api/scr/v1/screenshots' \
  -H "Authorization: OAuth $TOKEN" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -k \
  -d 'path=%2Fpreview%2Feditor%2F<CHART_ID>%3F_embedded%3D1&width=800&height=600'
```

### Извлечь данные чарта
```bash
curl -X POST 'https://charts.yandex-team.ru/api/run' \
  -H "Authorization: OAuth $TOKEN" \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"id": "<CHART_ID>", "params": {}}'
```

### Создать датасет из CHYT-таблицы (двухшаговый процесс)

`/rpc/createDataset` через Public API **не работает** для CHYT — используй validate + gateway.

```python
import requests, uuid

HEADERS_PUB = {"Authorization": "OAuth ...", "x-dl-api-version": "0", "Content-Type": "application/json"}
HEADERS_GW = {"Authorization": "OAuth ...", "Content-Type": "application/json"}

ds_uuid = str(uuid.uuid4())
param_hash = uuid.uuid4().hex[:16]

# Шаг 1: validateDataset — DS API сам прочитает схему таблицы из CHYT
validate_body = {
    "datasetId": "",
    "workbookId": None,
    "data": {
        "dataset": {
            "sources": [], "source_avatars": [], "result_schema": [],
            "result_schema_aux": {"inter_dependencies": {"deps": []}},
            "rls": {}, "rls2": {}, "obligatory_filters": [], "avatar_relations": [],
            "revision_id": None, "preview_enabled": True, "load_preview_by_default": True,
            "data_export_forbidden": False, "template_enabled": False,
            "component_errors": {"items": []}, "description": "",
        },
        "updates": [
            {
                "action": "add_source",
                "source": {
                    "id": ds_uuid, "title": "my_table", "group": [],
                    "source_type": "CHYT_TABLE",
                    "connection_id": "<CONNECTION_ID>",
                    "parameters": {"table_name": "//path/to/yt/table"},
                    "tab_title": "Таблица",
                    "form": [{"name": "table_name", "input_type": "text", "default": "",
                              "required": True, "title": "Путь к таблице в YT",
                              "field_doc_key": "CHYT_TABLE/table_name", "template_enabled": False}],
                    "disabled": False, "parameter_hash": param_hash,
                },
            },
            {
                "action": "add_source_avatar",
                "source_avatar": {"id": ds_uuid, "is_root": True, "title": "my_table", "source_id": ds_uuid},
            },
        ],
    },
}
# POST https://api.datalens.yandex.net/rpc/validateDataset
validated = requests.post(".../rpc/validateDataset", headers=HEADERS_PUB, json=validate_body).json()

# Опционально: поменять числовые поля на MEASURE
for f in validated["dataset"]["result_schema"]:
    if f["data_type"] == "float":
        f["type"] = "MEASURE"
        f["aggregation"] = "sum"

# Шаг 2: createDataset через Gateway API
# POST https://datalens.yandex-team.ru/gateway/root/bi/createDataset
create_body = {
    "dataset": validated["dataset"],  # результат validateDataset
    "dir_path": "folder/path/in/datalens",
    "name": "dataset_name",
}
result = requests.post(".../gateway/root/bi/createDataset", headers=HEADERS_GW, json=create_body).json()
dataset_id = result["id"]
```

Gateway API (`datalens.yandex-team.ru/gateway/root/bi/`) — внутренний API, который использует фронтенд DataLens. Не требует заголовок `x-dl-api-version`.

### Получить датасет (Public API)
```bash
curl -X POST 'https://api.datalens.yandex.net/rpc/getDataset' \
  -H "Authorization: OAuth $TOKEN" \
  -H 'x-dl-api-version: 0' \
  -H 'Content-Type: application/json' \
  -k \
  -d '{"datasetId": "<DATASET_ID>"}'
```

## Таксономия чартов

В DataLens два вида чартов:

### Wizard-чарты (через UI, самые распространённые)
Управление через Public API `/rpc/*WizardChart`. Типы:
- `graph_wizard_node` — линейные, area, столбчатые, barplot, scatter
- `d3_wizard_node` — pie, donut, treemap
- `table_wizard_node` — плоские и сводные таблицы
- `metric_wizard_node` — карточки с метриками

### Editor-чарты (через код)
Управление через Public API `/rpc/*EditorChart`. Типы:
- `graph_node` — Highcharts-чарт с JS-кодом
- `d3_node` — Gravity Charts (D3) с JS-кодом
- `table_node` — таблицы на коде
- `metric_node` — метрики на коде
- `timeseries_node` — временные ряды (Yagr)
- `markdown_node` — Markdown-текст
- `control_node` — кастомные селекторы
- `ymap_node` — Яндекс Карты

## Сетка дашборда

Сетка дашборда — **36 колонок**. Единица высоты = **18px**. Элементы позиционируются через `{i, h, w, x, y}`, где `i` — ID элемента.

## Форматы URL в DataLens

| Тип объекта | Формат URL |
|-------------|------------|
| Wizard-чарт | `https://datalens.yandex-team.ru/wizard/<entryId>` |
| Editor-чарт | `https://datalens.yandex-team.ru/editor/<entryId>` |
| Дашборд | `https://datalens.yandex-team.ru/<entryId>` |
| Датасет | `https://datalens.yandex-team.ru/datasets/<entryId>` |

**НЕ использовать** `https://datalens.yandex-team.ru/<entryId>` для чартов — вернёт «object not found». Чарты требуют префикс `/wizard/` или `/editor/`.

## Добавить формулу в датасет

Формулы (COUNTD, вычисляемые поля) добавляются через chained validateDataset:

```python
# Шаг 1: validateDataset с add_source (как при создании) → получить validated
# Шаг 2: validateDataset с add_field
validate_body = {
    "datasetId": "",   # пустая строка для нового
    "workbookId": None,
    "data": {
        "dataset": validated_from_step1,
        "updates": [
            {
                "action": "add_field",
                "field": {
                    "new_id": "my_formula",
                    "title": "my_formula",
                    "formula": "COUNTD([item_id])",
                    "calc_mode": "formula",
                    "type": "MEASURE",
                    "aggregation": "none",
                    "cast": "integer",
                    "hidden": False
                }
            }
        ],
    },
}
# Шаг 3: gateway createDataset с результатом
```

**Adhoc-формулы в чартах (datasetsPartialFields) НЕ работают** — DataLens data API ищет поле по guid только в датасете. Формулы — только через датасет.

## Миграция чартов на новый датасет

При пересоздании датасета (новый ID, новые guid полей) — нужна миграция ВСЕХ чартов и дашборда.

**Алгоритм:** regex-замена `"{field_name}_{4chars}"` → новый guid по всему shared config (JSON-строка). Заменять также `datasetId` и `avatar_id`.

Затронутые места: `visualization.placeholders[].items[]`, `sort[]`, `filters[]`, `colors[]`, `labels[]`, `tooltips[]`, `datasetsPartialFields[][]`.

На дашборде: `group_control` → `item.data.group[].source.datasetId` и `source.datasetFieldId`, `defaults` ключи.

## Обработка ошибок

- 401/403 — проверить OAuth-токен
- 404 — проверить entry ID или путь
- SSL-ошибки — добавить Yandex internal root CA
- Public API — всегда добавлять заголовок `x-dl-api-version: 0`
- `ENTRY_ALREADY_EXISTS` — путь ключа занят. Добавить суффикс или удалить существующий entry
- `ERR.DS_API.ROW_COUNT_LIMIT` — слишком много строк. Добавить `"extraSettings": {"pagination": "on", "limit": 100}` в shared config
- `ERR.CHARTS.ROWS_NUMBER_OVERSIZE` — metric rowsLimit=1000, table/chart rowsLimit=75000. Если metric возвращает >1000 строк — серверная агрегация не работает. **Решение:** использовать формулу (COUNTD/SUM) в датасете вместо countunique на DIMENSION
- **updateDataset ВАЙПИТ датасет!** `/rpc/updateDataset` через Public API СТИРАЕТ все поля и источники (проверено 3 раза). **НЕ использовать** для модификации. Вместо этого — удалить и пересоздать через validate+gateway
- **updateConnection — другая схема!** Не принимает поля из createConnection (`name`, `type`, `host` и т.д.). Проще delete + create заново
- **PostgreSQL timeout** — если `run-sql` возвращает timeout, скорее всего нет puncher-правила от `_DATALENS_PROD_NETS_` к MDB-хостам (см. раздел «Подключение PostgreSQL»)
- **createConnection 403** — нужен `dir_path` с папкой, к которой есть доступ (например `Users/<login>`)

## Python-скрипты для автоматизации

В директории `scripts/` находятся три скрипта для автоматизации работы с DataLens. Зависимости: только стандартная библиотека Python 3 (urllib).

### analyze.py — анализ дашбордов (read-path)

Структурный анализ дашборда, поиск чартов, извлечение данных, top-N по таблицам. Токен получается автоматически через skotty.

```bash
# Полный структурный анализ дашборда
python3 scripts/analyze.py <DASHBOARD_ID>

# Сохранить отчёт в файл
python3 scripts/analyze.py <DASHBOARD_ID> -o /tmp/report.json

# Список чартов дашборда (быстро)
python3 scripts/analyze.py <DASHBOARD_ID> --list-charts

# Инспекция чарта (SQL, connection, placeholders, colors)
python3 scripts/analyze.py --inspect-chart <CHART_ID>

# Найти релевантный чарт по запросу
python3 scripts/analyze.py <DASHBOARD_ID> --find-chart "country domain uniques" --find-limit 5

# Выполнить чарт с контекстом таба (дефолтные селекторы)
python3 scripts/analyze.py --run-chart-with-tab-context <DASHBOARD_ID> <CHART_ID>

# Получить только последнее значение каждой серии
python3 scripts/analyze.py --run-chart-with-tab-context <DASHBOARD_ID> <CHART_ID> --latest-only

# Top-N по табличному чарту
python3 scripts/analyze.py --run-topn <DASHBOARD_ID> <CHART_ID> \
  --period 2026-02 \
  --count-by uniques \
  --top-n 3

# Подобрать валидные значения селектора
python3 scripts/analyze.py --probe-selector-values <DASHBOARD_ID> <CHART_ID> count_by \
  --period 2026-02 \
  --probe-candidates '["hits","uniques","users"]'

# Значение в периоде
python3 scripts/analyze.py --run-chart <CHART_ID> \
  --value-at-period 2026-01 --aggregate stack-sum
```

### chart_ops.py — создание и редактирование чартов (write-path)

Создание QL-чартов из шаблона, добавление чартов на дашборд, замена чартов, ad-hoc SQL через dashsql.

```bash
# Выполнить SQL через dashsql connection
python3 scripts/chart_ops.py run-sql <CONNECTION_ID> \
  --sql "SELECT phone_pd_id FROM public.messages WHERE false"

# Создать QL-чарт из существующего шаблона
python3 scripts/chart_ops.py clone-ql-chart <SOURCE_CHART_ID> \
  --chart-key "Users/aostrikov/new-chart" \
  --sql "SELECT ..." \
  --x-guid day --x-title day \
  --y-guid metric --y-title metric

# Создать stacked/grouped чарт с color dimension
python3 scripts/chart_ops.py clone-ql-chart <SOURCE_CHART_ID> \
  --chart-key "Users/aostrikov/messages-by-sender" \
  --sql "SELECT date_trunc('day', created_at) AS day, role AS sender, count(*) AS count FROM public.messages GROUP BY day, sender" \
  --x-guid day --x-title day \
  --y-guid count --y-title count \
  --color-guid sender --color-title sender

# Создать QL-чарт и сразу опубликовать на дашборде
python3 scripts/chart_ops.py clone-ql-to-dashboard <DASHBOARD_ID> <SOURCE_CHART_ID> \
  --chart-key "Users/aostrikov/unique-users-by-day" \
  --sql "SELECT count(DISTINCT phone_pd_id) AS unique_users, date_trunc('day', created_at) AS day FROM public.messages WHERE phone_pd_id IS NOT NULL GROUP BY day ORDER BY day" \
  --widget-title "Unique Users per Day" \
  --anchor-chart-id <ANCHOR_CHART_ID> \
  --position right \
  --x-guid day --x-title day \
  --y-guid unique_users --y-title unique_users

# Добавить existing chart на dashboard
python3 scripts/chart_ops.py add-chart-to-dashboard <DASHBOARD_ID> <CHART_ID> \
  --widget-title "My Widget" \
  --anchor-chart-id <ANCHOR_CHART_ID> \
  --position right

# Заменить чарт в существующем виджете дашборда
python3 scripts/chart_ops.py replace-chart-on-dashboard <DASHBOARD_ID> <OLD_CHART_ID> <NEW_CHART_ID> \
  --widget-title "New Title"
```

## Бизнес-сценарии и интеграция с другими скиллами

Подробный справочник сценариев для разных ролей (аналитик, PM, SRE) и интеграций с другими скиллами SkillStore — в файле `references/business-scenarios.md`.

### Быстрый обзор интеграций

| Связка | Сценарий |
|--------|---------|
| DataLens + `exec-report` | Сбор метрик для еженедельного отчёта |
| DataLens + `monium` | Корреляция метрик с логами при инциденте |
| DataLens + `incident-report` | Скриншоты дашбордов в инцидент-репорт |
| DataLens + `yandex-tracker` | Привязка аномалий к задачам |
| DataLens + `systematic-debugging` | Дашборды как источник при расследовании |
| DataLens + `presentation-master` | Скриншоты дашбордов в презентацию |
| DataLens + `wiki` | Публикация аналитического отчёта |
| DataLens + `yql-query-runner` | Подготовка данных для датасетов |

### Типичные запросы пользователей

| Формулировка | Что делать |
|-------------|-----------|
| "Что на дашборде?" | `analyze.py <ID>` — полный обзор |
| "Скриншот" | Screenshots API, height=3000 |
| "Сравни с прошлым месяцем" | Два `--value-at-period` + дельта |
| "Почему метрика упала?" | `--run-topn` + `monium` логи |
| "Сделай чарт из таблицы" | validate dataset + create wizard chart |
