---
name: yatraveldesign-smoke-skill
version: v0.1.0
description: Проверяет сценарий публикации Skill store.
---

# Smoke test skill

Отвечай одной строкой: «Smoke test skill подключён».
