# Maintained room semantics

Use this reference for the current Travel room-icon set. These are maintained composition decisions, not universal interior-design rules. The user's latest request always wins. A reference image supplies only the role assigned to it; it does not silently restore removed objects.

## Shared rules

- Keep orange out of floor rugs and mats. Orange may remain on a meaningful non-rug accent already approved for a scene.
- Keep lavender restrained and match the perceived color of the canonical living-room cushion. Do not recolor functional objects merely for branding.
- Avoid tiny cups, scatter props and decorative clutter. Add no more than one meaningful supporting detail during an L enrichment pass.
- Preserve the canonical elevated 3/4 direction and calibrate optical mass as a set.

## Core rooms

- **Bedroom:** bed, warm milk-ivory bedding, soft-lavender throw and warm-ivory rug. No bedside table or lamp in the maintained composition.
- **Living room:** warm-ivory sofa, walnut-framed stone coffee table, warm-ivory rug and at most one lavender cushion. A single closed book is an acceptable L detail; no floor lamp.
- **Full kitchen:** tall brushed-silver refrigerator; cooktop, oven and hood group; separate walnut island with an uninterrupted milk-stone top. The island carries one walnut cutting board with rounded corners and an elongated oval grip hole. No sink, faucet, kettle, chair, knife, food, cups or utensils.
- **Kitchenette:** one low straight cabinet module with microwave, sink and faucet, one cutting board with an elongated oval grip hole, and one muted-lavender towel. No tall refrigerator, range hood or island. It must remain visibly distinct from the full kitchen.
- **Bathroom:** bathtub, brushed-silver standing faucet, walnut bath tray and one muted-lavender folded towel. No orange rug or replacement floor mat; avoid bottles and bath clutter.
- **Toilet:** mirror and milk-stone sink/vanity are dominant; the smaller warm-white toilet sits beside the vanity on the same floor level. Use a solid walnut base. No rug, orange mat, bottles, rolled towels, open cubbies or clipped external shadow patches.
- **Entryway:** standing mirror, upholstered bench, one simplified pair of shoes and one lavender scarf. Keep it distinct from a corridor.

## Outdoor and storage

- **Balcony:** brushed-silver railing, two simplified chairs with milk-ivory upholstery and a small dark-walnut table. No cushions or cups.
- **Courtyard:** tree and bench are the dominant pair. A small grass cluster may stay inside the existing planter; avoid loose landscaping clutter.
- **Terrace:** umbrella and primary daybed/seating group, milk-stone table and one muted-lavender throw. No cups.
- **Veranda:** open timber platform with canopy and simple milk-ivory seating. No railings or unsupported bars that lead nowhere.
- **Pool:** compact pool basin, clear turquoise water and ladder only. No chaise lounge or scatter accessories.
- **Walk-in wardrobe:** wardrobe/rack silhouette with a few broad garment blocks. A small folded knit stack is an acceptable L detail; avoid dense hangers.

## Extended rooms

- **Corridor:** no final composition is assumed when the user rejects the current one. Explore low-detail structural wireframes first. Keep it distinct from an entryway: circulation, doors/openings or a turn should dominate; avoid bench, mirror, shoes and coat hooks.
- **Steam room:** timber stepped bench, compact brushed-metal heater with stones, and at most one folded warm-ivory towel. Keep stone and towel texture quiet, not heavily embossed.
- **Dining area:** table and chairs with warm milk-ivory seats. Never use lavender upholstery for the chairs. One folded warm-ivory linen napkin is an acceptable L detail.
- **Nursery:** child's bed plus a clear play cue such as a rocking horse. One simple block is an acceptable L detail; avoid many tiny toys.
- **Workspace:** desk, chair and a CLOSED laptop. A single closed notebook is an acceptable L detail; do not reopen the laptop.
- **Gym:** exercise bench and grouped weights. Lavender upholstery is acceptable when it matches the canonical accent.
- **Relaxation area:** armchair and ottoman as the dominant group; a small stone side table is acceptable. No floor lamp in the maintained compact composition.
- **Garage:** car partially within a compact garage opening. Keep the scene uncluttered; no loose tools or storage scatter.
