# Startrek Entities API

## Overview

This guide focuses on the Tracker Entities API (`/v3/entities/*`) for:

- `project`
- `portfolio`
- `goal`

Use this API for modern project/goal/portfolio flows instead of legacy `/v2/projects` endpoints.

Primary docs:

- https://docs.yandex-team.ru/tracker/api-ref/entities/about-entities?lang=ru
- https://docs.yandex-team.ru/tracker/api-ref/entities/keyresults?lang=ru
- https://docs.yandex-team.ru/tracker/api-ref/entities/metric?lang=ru

## Entity Types And Params

### Entity types

- `project` - delivery/execution entity, can contain queues/issues and project metrics.
- `portfolio` - grouping/management entity for projects/goals.
- `goal` - objective entity; usually where key results are tracked.

### Core `fields` (request/response)

Common fields across types:

- `summary` (required on create)
- `description`
- `lead`
- `teamUsers`, `clients`, `followers`
- `tags`
- `entityStatus`
- `start`, `end`
- `parentEntity` (`primary`, `secondary`)

Type-specific high-signal fields:

- `project`: `issueQueues`, `metricItems`, `checklistItems`, `linkedGoalsCount`
- `portfolio`: `metricItems`, `checklistItems`, `linkedGoalsCount`
- `goal`: `keyResultItems`, `progressPercentage`, `linkedProjectsCount`

### Status values

- Project/portfolio statuses: `draft`, `draft2`, `in_progress`, `according_to_plan`, `postponed`, `at_risk`, `blocked`, `launched`, `cancelled`
- Goal statuses: `draft`, `according_to_plan`, `at_risk`, `blocked`, `achieved`, `partially_achieved`, `not_achieved`, `exceeded`, `cancelled`

### Relationship values (`links[].relationship`)

- For `project`/`portfolio`: `depends on`, `is dependent by`, `works towards`
- For `goal`: `parent entity`, `child entity`, `depends on`, `is dependent by`, `is supported by`

### Request parameter semantics

- `--fields` (query param): controls which extra entity fields are returned in response.
- `entities get/update`: optional `--fields`; update body is still required for `update`.
- `entities search`: supports `--per-page`, `--page`, `--fields`, `--input` (substring on `summary`), `--filter <json>` (arbitrary body filter, e.g. `{"parentEntity":"<id>"}` for child-entity lookups), `--order-by <field>`, `--order-asc` (default descending), `--root-only` (only non-nested entities).
- Update operators in `fields` objects may use list operations (`add`, `remove`) depending on field type.

## CLI Mapping

Use `startrek-cli entities ...`:

- `entities create <type> <json-body> [--fields f1,f2]`
- `entities get <type> <id> [--fields f1,f2]`
- `entities update <type> <id> <json-body> [--fields f1,f2]`
- `entities search <type> [--input <text>] [--filter <json>] [--order-by <field>] [--order-asc] [--root-only] [--per-page <n>] [--page <n>] [--fields f1,f2]`
- `entities delete <type> <id> [--with-board]`

`--fields` controls response projection. It does not replace request body JSON.

## Common Patterns

### Create project

```bash
startrek-cli entities create project '{"fields":{"summary":"Mobile Reliability","lead":"username"}}'
```

### Search projects (replacement for list/suggest)

```bash
# List page
startrek-cli entities search project --per-page 50 --page 1

# Suggest by substring
startrek-cli entities search project --input "mobile" --fields summary,entityStatus

# Child goals of a parent goal (use the entity id, not shortId)
PARENT_ID=$(startrek-cli entities get goal 536921 --json | jq -r .id)
startrek-cli entities search goal --filter "{\"parentEntity\":\"$PARENT_ID\"}" \
  --fields summary,entityStatus,shortId --per-page 100

# Top-level (root) goals only, oldest first
startrek-cli entities search goal --root-only --order-by shortId --order-asc \
  --per-page 50 --fields summary,entityStatus
```

`--filter` accepts a JSON object that is sent as the request body's `filter` field. Common keys: `parentEntity` (entity id; use raw uuid, no `goal/` prefix), `entityStatus`, `lead`, `author`, `tags`. Pair with `--fields` to control which fields come back in each value.

### Read selected fields

```bash
startrek-cli entities get project 514132 --fields summary,entityStatus,issueQueues,metricItems
```

### Update entity fields

```bash
startrek-cli entities update project 514132 '{"fields":{"summary":"New name"}}'
```

## Key Results (`keyResultItems`)

Field is primarily used for `goal` entities.

### Replace key results list

```bash
startrek-cli entities update goal 655f328xxxxxxxxx '{
  "fields": {
    "keyResultItems": [
      {
        "type": "value",
        "text": "KR: reduce p95 latency",
        "assignee": "username1",
        "deadline": {"date": "2026-12-01", "deadlineType": "date"},
        "progress": {"start": 100, "end": 50, "current": 78}
      },
      {
        "type": "binary",
        "text": "KR: launch fallback flow",
        "assignee": "username2",
        "deadline": {"date": "2026-12-15", "deadlineType": "date"},
        "achieved": false
      }
    ]
  }
}' --fields keyResultItems
```

### Add one KR

```bash
startrek-cli entities update goal 655f328xxxxxxxxx '{
  "fields": {
    "keyResultItems": {
      "add": {
        "type": "binary",
        "text": "KR: complete migration",
        "assignee": "username3"
      }
    }
  }
}' --fields keyResultItems
```

### Remove all KRs

```bash
startrek-cli entities update goal 655f328xxxxxxxxx '{"fields":{"keyResultItems":null}}' --fields keyResultItems
```

## Metrics (`metricItems`)

Supported on `project`, `portfolio`, and `goal`.

### Replace metrics list

```bash
startrek-cli entities update project 655f8cc52xxxxxxxx '{
  "fields": {
    "metricItems": [
      {
        "text": "Crash-free sessions",
        "url": "https://tracker.yandex-team.ru/dashboard/12/widget/34?_embedded=1&_no_controls=1"
      },
      {
        "text": "Checkout conversion",
        "url": "https://tracker.yandex-team.ru/dashboard/23/widget/45?_embedded=1&_no_controls=1"
      }
    ]
  }
}' --fields metricItems
```

### Add one metric

```bash
startrek-cli entities update project 655f8cc52xxxxxxxx '{
  "fields": {
    "metricItems": {
      "add": {
        "text": "DAU",
        "url": "https://tracker.yandex-team.ru/dashboard/12/widget/34?_embedded=1&_no_controls=1"
      }
    }
  }
}' --fields metricItems
```

### Remove all metrics

```bash
startrek-cli entities update project 655f8cc52xxxxxxxx '{"fields":{"metricItems":null}}' --fields metricItems
```

## Notes

- For item-level `remove` in `metricItems`/`keyResultItems`, pass the object in the same shape that `entities get ... --fields ...` returns.
- The link between a project and an issue is updated on the issue side. Do not use `entities update` or entity links to move an issue into or out of a project; use `startrek-cli issues update ...` for that.
- Field keys in entities can differ from issue field keys.
- For tracker query language, see `query-language.md`.
