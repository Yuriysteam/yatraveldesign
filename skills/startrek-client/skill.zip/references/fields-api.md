# Fields API

Use `startrek-cli fields` to manage global Tracker fields and field categories.

## Commands

```bash
startrek-cli fields list
startrek-cli fields get <fieldId>
startrek-cli fields create <json-body>
startrek-cli fields update <fieldId> --version <version> <json-body>
startrek-cli fields categories
startrek-cli fields category-create <json-body>
startrek-cli fields category-update <categoryId> --version <version> <json-body>
```

Pass request bodies as positional JSON strings. Use `--json` to get the raw API response.

Update commands require the current `version` from the existing field or category.

## Examples

List fields:

```bash
startrek-cli fields list
```

Create a category:

```bash
startrek-cli fields category-create '{"id":"gena","name":{"en":"GENA","ru":"GENA"}}'
```

Create a simple string field:

```bash
startrek-cli fields create '{"id":"gena_model","name":{"en":"GENA model","ru":"GENA model"},"category":"gena","type":"ru.yandex.startrek.core.fields.StringFieldType","visible":true}'
```

Create a fixed-list field:

```bash
startrek-cli fields create '{"id":"gena_effort","name":{"en":"GENA effort","ru":"GENA effort"},"category":"gena","type":"ru.yandex.startrek.core.fields.StringFieldType","visible":true,"optionsProvider":{"type":"FixedListOptionsProvider","values":["low","medium","high","max"]}}'
```

Update a field after reading its current version:

```bash
startrek-cli fields get gena_effort --json
startrek-cli fields update gena_effort --version 3 '{"name":{"en":"GENA effort","ru":"GENA effort"}}'
```

## GENA Fields

Recommended global fields for GENA provisioning:

| ID                        | Type                                                                    |
| ------------------------- | ----------------------------------------------------------------------- |
| `gena_model`              | `ru.yandex.startrek.core.fields.StringFieldType`                        |
| `gena_engine`             | `ru.yandex.startrek.core.fields.StringFieldType` with fixed-list values |
| `gena_effort`             | `ru.yandex.startrek.core.fields.StringFieldType` with fixed-list values |
| `gena_additional_presets` | Multi-value string field with `container: true` or text field           |
