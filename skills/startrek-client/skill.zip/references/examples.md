# Startrek Client Reference

## Overview

CLI for Yandex Tracker (Startrek). Covers issues (CRUD, comments, links, remote links, transitions, attachments, changelog, move), entities (projects/portfolios/goals), boards (boards, columns, sprints), queues, and worklog. Token: `STARTREK_TOKEN` (resolved by the CLI from env or auto-fetched if not set; set `DISABLE_AUTO_FETCH_TOKEN=true` to require an explicit token).

**Security**: `issues.get()` automatically blocks issues from queues with `securityLevel: "protect_sensitive_data"` or with a "Secret" component, throwing `StartrekSensitiveIssueError`. This applies to both CLI usage and programmatic API calls.

See [Startrek Query Language](query-language.md) for search query syntax.
For advanced entities workflows (create/search, `keyResultItems`, `metricItems`), see [Startrek Entities API](entities-api.md).

## Issue Link Relationships

Issue links connect two Tracker issues. The `relationship` value determines the link type:

| Relationship         | Description                                      |
| -------------------- | ------------------------------------------------ |
| `relates`            | Simple related link (symmetric)                  |
| `depends on`         | Current issue is blocked by target               |
| `is dependent by`    | Current issue blocks target                      |
| `is subtask for`     | Current issue is a subtask of target             |
| `is parent task for` | Current issue is parent of target                |
| `duplicates`         | Current issue duplicates target                  |
| `is duplicated by`   | Target duplicates current issue                  |
| `is epic of`         | Current issue is epic of target (Epic type only) |
| `has epic`           | Target is epic of current issue                  |

```bash
# Link two related issues
startrek-cli issues link ITAXI-123 relates ITAXI-456

# Mark ITAXI-789 as blocked by ITAXI-123
startrek-cli issues link ITAXI-123 "is dependent by" ITAXI-789

# Create parent-subtask relationship
startrek-cli issues link ITAXI-100 "is parent task for" ITAXI-101

# List all links on an issue
startrek-cli issues links ITAXI-40073
startrek-cli issues links ITAXI-40073 --json
```

## Remote Links (External Systems)

Remote links connect a Tracker issue to objects in external applications. **Arcanum PRs are attached to issues as remote links** — use `issues remotelinks` to find PRs linked to a task.

**Known application origins:**

| Origin               | Application           | Key format            | Example                            |
| -------------------- | --------------------- | --------------------- | ---------------------------------- |
| `ru.yandex.arcanum`  | Arcanum (PRs)         | PR number             | `7902850`                          |
| `ru.yandex.testpalm` | TestPalm              | project/testcase path | `myproject/testcases/42`           |
| `tms`                | TMS (test management) | project/testcase path | `projects/go_yango/testcases/1321` |

```bash
# Find PRs and other external links on an issue
startrek-cli issues remotelinks ITAXI-40073
startrek-cli issues remotelinks ITAXI-40073 --json

# JSON output includes object.application.name (e.g., "Arcanum") and object.key (PR number)
```

**Remote link fields in `--json` output:**

- `object.key` — identifier in the external system (e.g., PR number)
- `object.application.name` — application name (e.g., `"Arcanum"`, `"TestPalm"`)
- `type.id` — relationship type (typically `"relates"`)
- `direction` — `"inward"` or `"outward"`

## Boards, Columns, and Sprints

Boards organize issues into visual columns. Each board has a type, columns with mapped statuses, and optionally sprints (for scrum boards).

**Board types:** `default`, `scrum`, `kanban`

**Sprint statuses:** `draft`, `in_progress`, `released`, `archived`

**Version / If-Match pattern:** Board `update`, column `create`/`update`/`delete` require `--version` for optimistic concurrency. Get the current version from `boards get <id>` (`version` field), then pass it via `--version`. If the version doesn't match (someone edited the board concurrently), the API returns a 412 Precondition Failed error.

```bash
# List all boards
startrek-cli boards list
startrek-cli boards list --json

# Get board details (includes version and columns)
startrek-cli boards get 123
startrek-cli boards get 123 --json

# Create a board
startrek-cli boards create --name "Sprint Board" --queue TREK --type scrum
startrek-cli boards create --name "Filtered Board" --queue TREK --query "Priority: Critical"

# Update a board (requires --version)
startrek-cli boards update 123 --version 5 '{"name":"Renamed Board"}'

# Delete a board
startrek-cli boards delete 123

# List columns on a board
startrek-cli boards columns 123
startrek-cli boards columns 123 --json

# Get a specific column
startrek-cli boards column 123 1

# Create a column (requires --version)
startrek-cli boards create-column 123 --version 5 --name "In Review" --statuses needInfo,review

# Update a column (requires --version)
startrek-cli boards update-column 123 1 --version 5 '{"name":"Code Review"}'

# Delete a column (requires --version)
startrek-cli boards delete-column 123 1 --version 5

# List sprints on a board
startrek-cli boards sprints 123
startrek-cli boards sprints 123 --json

# Get sprint details
startrek-cli boards sprint 456

# Create a sprint
startrek-cli boards create-sprint --name "Sprint 42" --board 123 --start 2025-01-01 --end 2025-01-14
```

## Error Classes

| Error                          | Status | Description                                                                       |
| ------------------------------ | ------ | --------------------------------------------------------------------------------- |
| `StartrekApiError`             | any    | Base API error with statusCode and responseBody                                   |
| `StartrekBadRequestError`      | 400    | Bad request                                                                       |
| `StartrekUnauthorizedError`    | 401    | Unauthorized                                                                      |
| `StartrekForbiddenError`       | 403    | Forbidden                                                                         |
| `StartrekNotFoundError`        | 404    | Not found                                                                         |
| `StartrekConflictError`        | 409    | Conflict                                                                          |
| `StartrekTimeoutError`         | --     | Request timeout                                                                   |
| `StartrekNetworkError`         | --     | Network error                                                                     |
| `StartrekSensitiveIssueError`  | --     | Issue is in a protected-security-level queue or has a "Secret" component          |

## Entity Sub-APIs

Entities (projects, portfolios, goals) have sub-APIs for comments, links, attachments, checklists, bulk changes, events, and permissions. All commands take `<type>` (`project`, `portfolio`, or `goal`) and `<id>` (entity ID).

### Entity Creation And Search

For detailed entity-focused examples, including project creation/search and fields like `keyResultItems` and `metricItems`, use [Startrek Entities API](entities-api.md).

### Entity Comments

```bash
# Create a comment
startrek-cli entities comment project 514132 "Status update: on track"

# List all comments
startrek-cli entities comments project 514132
startrek-cli entities comments project 514132 --expand all --json

# Paginated comments (cursor-based)
startrek-cli entities comments-paginated project 514132 --per-page 10 --direction desc

# Get a single comment
startrek-cli entities comment-get project 514132 abc123

# Edit a comment
startrek-cli entities comment-edit project 514132 abc123 "Updated text"

# Delete a comment
startrek-cli entities comment-delete project 514132 abc123
```

### Entity Links

Relationship types for projects/portfolios: `depends on`, `is dependent by`, `works towards`.
Relationship types for goals: `parent entity`, `child entity`, `depends on`, `is dependent by`, `is supported by`.

`entities add-links` and `entities delete-link` only manage links between Tracker entities (`project`/`portfolio`/`goal`). If you need to change the link between a project and an issue, update the issue with `startrek-cli issues update ...` instead of changing entity links on the project.

```bash
# List entity links
startrek-cli entities links project 514132
startrek-cli entities links project 514132 --fields summary --json

# Add links (JSON array)
startrek-cli entities add-links project 514132 '[{"relationship":"depends on","entity":"655f328da"}]'

# Delete a link (specify target entity ID)
startrek-cli entities delete-link project 514132 --right 655f328da
```

### Entity Attachments

```bash
# List all attachments
startrek-cli entities attachments project 514132

# Get a single attachment
startrek-cli entities attachment project 514132 file123

# Attach a previously uploaded file
startrek-cli entities attach-file project 514132 file123

# Delete an attachment
startrek-cli entities delete-attachment project 514132 file123
```

### Entity Checklists

```bash
# Add checklist items
startrek-cli entities checklist-add project 514132 '[{"text":"Task 1"},{"text":"Task 2","checked":true}]'

# Edit multiple items (batch, requires item IDs)
startrek-cli entities checklist-edit project 514132 '[{"id":"item1","text":"Updated"},{"id":"item2","checked":true}]'

# Edit a single item
startrek-cli entities checklist-edit-item project 514132 item1 '{"text":"New text","checked":true}'

# Move an item before another
startrek-cli entities checklist-move project 514132 item2 --before item1

# Delete a single item
startrek-cli entities checklist-delete-item project 514132 item1

# Delete all items
startrek-cli entities checklist-delete-all project 514132
```

### Entity Bulk Change

```bash
# Bulk update multiple entities
startrek-cli entities bulk-update project '{"metaEntities":[{"id":"1","entityType":"project"},{"id":"2","entityType":"project"}],"values":{"fields":{"entityStatus":"in_progress"}}}'
```

### Entity Events (History)

```bash
# Get event history (cursor-based pagination)
startrek-cli entities events project 514132
startrek-cli entities events project 514132 --per-page 20 --direction desc --json
```

### Entity Permissions

```bash
# Get current permissions
startrek-cli entities permissions project 514132

# Update permissions (grant/revoke)
startrek-cli entities update-permissions project 514132 '{"acl":{"grant":{"READ":{"users":["user1","user2"]}}}}'
```

## CLI Reference

```bash
startrek-cli <command> [options]

Commands:
  # Issues
  issues get <key>                       Get issue details (all fields by default)
  issues search <query> [--per-page <n>] [--page <n>]  Search issues with pagination
  issues create --queue <Q> --summary <S> [--description <D>] [--type <T>] [--assignee <A>]
  issues update <key> <json-body>        Update issue fields (storyPoints, sprint, assignee, project linkage, etc.)
  issues comment <key> <text>            Create comment on issue
  issues comment-get <key> <commentId> [--expand <fields>]  Get single comment by ID
  issues comment-edit <key> <commentId> <text>  Edit a comment
  issues comment-delete <key> <commentId>  Delete a comment
  issues comments <key> [--per-page <n>] [--expand <fields>]  List comments on issue
  issues changelog <key> [--per-page <n>] [--field <f>] [--type <t>]  Get issue change history
  issues attachments <key>               List attachments on issue
  issues attachment <key> <attachmentId> Get single attachment by ID
  issues transitions <key>               List available status transitions
  issues move <key> <queue> [--notify] [--no-notify] [--notify-author] [--move-all-fields] [--initial-status]
                                             (--notify is on by default; use --no-notify to suppress)
  issues count <query>                   Count matching issues
  issues links <key>                     List issue links (issue-to-issue)
  issues link <key> <relationship> <target>  Create issue link
  issues remotelinks <key>               List remote links (external systems)
  issues delete-remote-link <key> <linkId>  Delete a remote link (numeric link ID)

  # Transitions
  transitions execute <key> <id>         Execute status transition

  # Entities (projects/portfolios/goals)
  entities create <type> <json-body> [--fields f1,f2]  Create entity
  entities get <type> <id> [--fields f1,f2]  Get entity
  entities update <type> <id> <json-body> [--fields f1,f2]  Update entity
  entities search <type> [--input <text>] [--filter <json>] [--order-by <field>] [--order-asc] [--root-only] [--per-page <n>] [--page <n>] [--fields f1,f2]  Search entities
  entities delete <type> <id> [--with-board]  Delete entity

  # Entity Comments
  entities comment <type> <id> <text>          Create comment on entity
  entities comments <type> <id> [--expand]     List all comments
  entities comments-paginated <type> <id> [--per-page <n>] [--from <id>] [--direction asc|desc]
  entities comment-get <type> <id> <commentId> [--expand]  Get single comment
  entities comment-edit <type> <id> <commentId> <text>     Edit comment
  entities comment-delete <type> <id> <commentId>          Delete comment

  # Entity Links
  entities links <type> <id> [--fields]        List entity links
  entities add-links <type> <id> <json-array>  Add links
  entities delete-link <type> <id> --right <entityId>  Delete link

  # Entity Attachments
  entities attachments <type> <id>             List attachments
  entities attachment <type> <id> <fileId>     Get attachment
  entities attach-file <type> <id> <fileId>    Attach file
  entities delete-attachment <type> <id> <fileId>  Delete attachment

  # Entity Checklists
  entities checklist-add <type> <id> <json-items>  Add checklist items
  entities checklist-edit <type> <id> <json-items>  Edit multiple items
  entities checklist-edit-item <type> <id> <itemId> <json>  Edit single item
  entities checklist-move <type> <id> <itemId> --before <id>  Move item
  entities checklist-delete-item <type> <id> <itemId>  Delete single item
  entities checklist-delete-all <type> <id>    Delete all items

  # Entity Bulk Change
  entities bulk-update <type> <json-body>      Bulk change entities

  # Entity Events
  entities events <type> <id> [--per-page <n>] [--from <id>] [--direction asc|desc]

  # Entity Permissions
  entities permissions <type> <id>             Get permissions
  entities update-permissions <type> <id> <json-body>  Update permissions

  # Queues
  queues get <id> [--expand <fields>]    Get queue details
  queues list [--per-page <n>] [--expand <fields>]  List all accessible queues

  # Worklog (time tracking)
  worklog list <key> [--per-page <n>]    List worklog entries for issue
  worklog create <key> --start <datetime> --duration <dur> [--comment <text>]  Create worklog entry
  worklog edit <key> <worklogId> [--start <datetime>] [--duration <dur>] [--comment <text>]  Edit worklog entry
  worklog delete <key> <worklogId>       Delete worklog entry

  # Boards
  boards list                            List all boards
  boards get <id>                        Get board details
  boards create --name <N> --queue <Q> [--type <T>] [--query <Q>]  Create a board
  boards update <id> --version <V> <json-body>  Update board (requires --version)
  boards delete <id>                     Delete a board
  boards columns <id>                    List columns on a board
  boards column <boardId> <columnId>     Get a specific column
  boards create-column <boardId> --version <V> --name <N> --statuses <s1,s2>  Create column
  boards update-column <boardId> <columnId> --version <V> <json-body>  Update column
  boards delete-column <boardId> <columnId> --version <V>  Delete column
  boards sprints <id>                    List sprints on a board
  boards sprint <sprintId>               Get sprint details
  boards create-sprint --name <N> --board <B> --start <D> --end <D>  Create sprint

Options:
  --expand <fields>    Comma-separated expand fields (e.g., transitions,attachments)
  --json               Output raw JSON
  --help               Show help

Search Query DSL:
  Search queries use Tracker Query Language: `Field: value` pairs.
  Multiple conditions are ANDed together with semicolons or spaces.
  Examples: `"Queue: ITAXI Status: Open"`, `"Queue: ITAXI Assignee: username"`

Examples:
  startrek-cli issues get ITAXI-40073
  startrek-cli issues get ITAXI-40073 --expand transitions,attachments
  startrek-cli issues search "Queue: ITAXI Status: Open"
  startrek-cli issues search "Queue: ITAXI" --per-page 10 --page 2
  startrek-cli issues create --queue ITAXI --summary "Fix bug" --assignee username
  startrek-cli issues update ITAXI-40073 '{"storyPoints": 0.5}'
  startrek-cli issues update ITAXI-40073 '{"sprint": [{"id": "268809"}]}'
  startrek-cli issues update ITAXI-40073 '{"storyPoints": 1, "originalEstimation": 1, "spent": 0.5}'
  startrek-cli issues update ITAXI-40073 '{"assignee": "username"}'
  startrek-cli issues comment-get ITAXI-40073 123456
  startrek-cli issues comment-edit ITAXI-40073 123456 "Updated text"
  startrek-cli issues comment-delete ITAXI-40073 123456
  startrek-cli issues changelog ITAXI-40073
  startrek-cli issues changelog ITAXI-40073 --field status --per-page 10
  startrek-cli issues attachments ITAXI-40073
  startrek-cli issues attachment ITAXI-40073 55555
  startrek-cli issues links ITAXI-40073
  startrek-cli issues link ITAXI-40073 relates TREK-456
  startrek-cli issues remotelinks ITAXI-40073
  startrek-cli issues delete-remote-link ITAXI-40073 12345
  startrek-cli issues comments ITAXI-40073
  startrek-cli issues comments ITAXI-40073 --per-page 10 --expand all
  startrek-cli issues transitions ITAXI-40073
  startrek-cli issues move ITAXI-40073 TREK
  startrek-cli issues move ITAXI-40073 TREK --no-notify --move-all-fields
  startrek-cli issues count "Queue: ITAXI"
  startrek-cli transitions execute ITAXI-40073 resolve
  startrek-cli entities create project '{"fields":{"summary":"Test Project"}}'
  startrek-cli entities create project '{"fields":{"summary":"Mobile Reliability","lead":"username"},"links":[{"relationship":"works towards","entity":"1234"}]}'
  startrek-cli entities get project 655f328da123
  startrek-cli entities get project 514132 --fields summary,entityStatus,queues --json
  startrek-cli entities update project 514132 '{"fields":{"summary":"New name"}}'
  startrek-cli entities search project --input "mobile" --fields summary,entityStatus
  startrek-cli entities search goal --filter '{"parentEntity":"<entity-uuid>"}' --fields summary,entityStatus,shortId --per-page 100 --json
  startrek-cli entities search goal --root-only --order-by shortId --order-asc --per-page 50 --fields summary --json
  startrek-cli entities delete project 514132
  startrek-cli entities comment project 514132 "Status update"
  startrek-cli entities comments project 514132 --json
  startrek-cli entities links project 514132
  startrek-cli entities attachments project 514132
  startrek-cli entities checklist-add project 514132 '[{"text":"Task 1"}]'
  startrek-cli entities events project 514132 --per-page 10
  startrek-cli entities permissions project 514132
  startrek-cli queues get TREK
  startrek-cli queues get TREK --expand types,team
  startrek-cli queues list --per-page 100
  startrek-cli worklog list ITAXI-40073
  startrek-cli worklog create ITAXI-40073 --start "2025-01-15T09:00:00" --duration PT4H30M --comment "Code review"
  startrek-cli worklog edit ITAXI-40073 12345 --duration PT5H
  startrek-cli worklog delete ITAXI-40073 12345
  startrek-cli boards list
  startrek-cli boards get 123 --json
  startrek-cli boards create --name "Sprint Board" --queue TREK --type scrum
  startrek-cli boards update 123 --version 5 '{"name":"Renamed"}'
  startrek-cli boards columns 123
  startrek-cli boards create-column 123 --version 5 --name "Review" --statuses needInfo,review
  startrek-cli boards sprints 123
  startrek-cli boards sprint 456
  startrek-cli boards create-sprint --name "Sprint 42" --board 123 --start 2025-01-01 --end 2025-01-14
```
