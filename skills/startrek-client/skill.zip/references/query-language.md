# Tracker Query Language Reference

The Yandex Tracker query language is used in the `query` field of `SearchIssuesRequest` (both `search` and `count` methods).

## Basic Syntax

```
"Parameter": "value"
```

Parameters can use English field names. Quotes around parameter names are optional for single-word names, required for multi-word names.

## Logical Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `AND` (or space) | Both conditions must match | `Queue: TEST AND Status: Open` |
| `OR` | At least one condition must match | `Status: Open OR Status: "In Progress"` |
| `()` | Grouping (overrides precedence) | `Queue: TEST AND (Status: Open OR Status: Closed)` |

`AND` has higher precedence than `OR`.

## Multiple Values

Comma-separated values act as OR within the same field:

```
Status: Open, "In Progress", Closed
```

## Comparison Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `:` | Equals | `Queue: TEST` |
| `: !` | Not equals | `Priority: !"Minor"` |
| `: >` | Greater than | `Votes: >6` |
| `: <` | Less than | `Created: <2024-01-30` |
| `: >=` | Greater or equal | `"Story Points": >=5` |
| `: <=` | Less or equal | `Deadline: <=today()+3d` |
| `: ..` | Range (inclusive) | `Created: 2024-01-01..2024-01-30` |

## Text Search

| Syntax | Description | Example |
|--------|-------------|---------|
| `"text"` | Fuzzy match (words + word forms) | `Summary: "fix login"` |
| `#"text"` | Exact phrase match | `Summary: #"Version 2.0"` |
| `!"text"` | Text must NOT be present | `Summary: !"UI"` |
| `~"text"` | Title does NOT exactly match (Summary only) | `Summary: ~"UI Update 2.0"` |

Bare text (without a field name) searches across Summary, Description, and Comments.

### Text Search Fields

- `Summary` — issue title
- `Description` — issue description
- `Comment` — comment text
- `History` — change history (title and description changes only)

## Functions

| Function | Returns | Example |
|----------|---------|---------|
| `empty()` | Empty value (field not set) | `Assignee: empty()` |
| `notEmpty()` | Any non-empty value | `Deadline: notEmpty()` |
| `me()` | Current user | `Assignee: me()` |
| `now()` | Current time (minute precision) | `Created: >now()-12h` |
| `today()` | Current date interval | `Created: today()` |
| `week()` | Current week interval | `Created: week()` |
| `month()` | Current month interval | `Created: month()` |
| `quarter()` | Current quarter interval | `Created: quarter()` |
| `year()` | Current year interval | `Created: year()` |
| `unresolved()` | No resolution set | `Resolution: unresolved()` |
| `group(value: "name")` | Users in a department | `Assignee: group(value: "QA Team")` |

## Date/Time Formats

**Date:**
- `YYYY-MM-DD` — `2024-04-30`
- `MM/DD/YYYY` — `04/30/2024`
- `DD.MM.YYYY` — `30.04.2024`
- `DD-MM-YYYY` — `30-04-2024`

**Date and time:**
- `"YYYY-MM-DD HH:mm:ss"` — `"2024-04-30 17:25:00"`

**Duration (for arithmetic):**
- `"XXM XXw XXd XXh XXm XXs"` — `"2M 3d 5h 32m"` (2 months, 3 days, 5 hours, 32 minutes)

## Change History Filter

Search by field change history:

```
Status: changed(to: "In Progress" by: login@ date: >today()-1w)
```

Parameters inside `changed()` are all optional: `from`, `to`, `by`, `date`.

## Sorting

Append `"Sort By"` at the end of the query:

```
"Sort By": Created DESC
"Sort By": Priority ASC, Updated DESC
```

## User Search

| Syntax | Description | Example |
|--------|-------------|---------|
| `login@` | Exact login match (most precise) | `Assignee: user3370@` |
| `"First Last"` | Match by display name | `Author: "John Smith"` |
| `name` | Match login or first name | `Followers: john` |

## Common Filter Fields

| Field | Value Type | Description |
|-------|-----------|-------------|
| `Queue` | Queue key | Filter by queue (`Queue: TEST`) |
| `Status` | Status name | Filter by status (`Status: Open, Closed`) |
| `Type` | Issue type | Filter by type (`Type: Bug, Epic`) |
| `Priority` | Priority name | Filter by priority (`Priority: Critical, Blocker`) |
| `Assignee` | User | Filter by assignee |
| `Author` | User | Filter by creator |
| `Followers` | User | Filter by watchers |
| `Resolution` | Resolution name | Filter by resolution |
| `Created` | Date/range | Filter by creation date |
| `Updated` | Date/range | Filter by last update date |
| `Resolved` | Date/range | Filter by resolution date |
| `Deadline` | Date/range | Filter by deadline |
| `Tags` | Tag names | Filter by tags (`Tags: "backend", "v2"`) |
| `Components` | Component names | Filter by components |
| `Sprint` | Sprint name/ID | Filter by sprint |
| `Project` | Project name | Filter by project |
| `Summary` | Text | Search in title |
| `Description` | Text | Search in description |
| `Comment` | Text | Search in comments |
| `Key` | Issue keys | Filter by issue key (`Key: "TEST-123"`) |
| `"Story Points"` | Number | Filter by story points |
| `"Fix Version"` | Version name | Filter by fix version |
| `"Affected Version"` | Version name | Filter by affected version |
| `"Start Date"` | Date/range | Filter by start date |
| `"End Date"` | Date/range | Filter by end date |
| `"Original Estimate"` | Duration | Filter by original estimate |
| `"Time Spent"` | Duration | Filter by time spent |
| `"Parent Task"` | Issue key | Filter by parent task |
| `Votes` | Number | Filter by vote count |
| `"Linked to"` | Issue keys | Issues linked to given issues (any link type) |
| `Relates` | Issue keys | Issues related to given issues |
| `"Depends On"` | Issue keys | Issues blocked by given issues |
| `"Is Dependent By"` | Issue keys | Issues blocking given issues |
| `Epic` | Issue keys | Issues belonging to given epics |
| `Clone` | Issue keys | Issues cloned from given issues |
| `Filter` | Filter name/ID | Apply a saved filter |

## Useful Examples

```
# My open issues
Assignee: me() Resolution: empty()

# Issues I created that are still open
Author: me() Resolution: empty()

# My issues with deadline this week
Assignee: me() Deadline: week()

# Critical/Blocker issues I'm involved in
(Followers: me() OR Assignee: me() OR Author: me()) AND Resolution: empty() AND Priority: Blocker, Critical

# Issues created in the last 7 days
Created: >today()-1w

# Issues in queue TEST updated this month
Queue: TEST Updated: month()

# Overdue issues
Deadline: <today() Resolution: empty()

# Issues where status changed to "In Progress" in the last week
Status: changed(to: "In Progress" date: >today()-1w)

# Count all open bugs in a queue
Queue: MYQUEUE Type: Bug Resolution: empty()
```
