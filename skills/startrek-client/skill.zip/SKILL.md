---
name: startrek-client
description: Используй для чтения, поиска, создания и обновления задач Яндекс Трекера, комментариев, связей, переходов, досок и рабочих логов через startrek-cli.
---

# Трекер

Интерфейс командной строки для Яндекс Трекера. Поддерживает задачи, комментарии, связи, переходы, вложения, историю, сущности, поля, доски, очереди и рабочие логи. Токен передаётся только через `STARTREK_TOKEN`.

**Security:** `issues.get()` automatically blocks issues from queues with `securityLevel: "protect_sensitive_data"` or with a "Secret" component.

## Установка

Используй глобально установленный `startrek-cli`. Если его нет, установи `@yandex-tools/ai-startrek-cli` из `https://npm.yandex-team.ru/`.

## Special Concepts

### Issue Link Relationships

Common issue-link relationship values:

-   `relates`
-   `depends on`
-   `is dependent by`
-   `is subtask for`
-   `is parent task for`
-   `duplicates`
-   `is duplicated by`
-   `is epic of`
-   `has epic`

### Remote Links

Remote links attach a Tracker issue to objects in external systems. Arcanum PRs are attached as remote links, so `issues remotelinks` is the right command when the task is "find the PR linked to this issue".

### Boards And Versioning

Board and column update or delete operations require `--version` for optimistic concurrency. Read the current board first, take its `version`, then pass that value back into the mutation.

### Fields And Versioning

Field and field category update operations require `--version` for optimistic concurrency. Read the current field or category first, take its `version`, then pass that value back into the mutation.

## Backend And API Model

-   `startrek-cli` talks to Tracker's HTTP API for issues, transitions, links, remote links, queues, boards, worklog, and entities
-   Search uses Tracker Query Language and sends the query as a raw search string
-   Entities live in a separate API family and model higher-level objects such as `project`, `portfolio`, and `goal`
-   Field administration supports global fields and field categories through `fields *` commands
-   `--fields` on entity commands is a response projection, not a replacement for the JSON body
-   Some entity list fields use replace/add/remove update semantics instead of plain overwrite
-   Remote links are the integration surface for external systems such as Arcanum pull requests

## CLI Reference

```bash
startrek-cli <command> [options]

Commands:
  # Issues
  issues get <key>
  issues search <query> [--per-page <n>] [--page <n>]
  issues create --queue <Q> --summary <S> [--description <D>] [--type <T>] [--assignee <A>]
  issues update <key> <json-body>
  issues comment <key> <text>
  issues comment-get <key> <commentId> [--expand <fields>]
  issues comment-edit <key> <commentId> <text>
  issues comment-delete <key> <commentId>
  issues comments <key> [--per-page <n>] [--expand <fields>]
  issues changelog <key> [--per-page <n>] [--field <f>] [--type <t>]
  issues attachments <key>
  issues attachment <key> <attachmentId>
  issues transitions <key>
  issues move <key> <queue> [--notify] [--no-notify] [--notify-author] [--move-all-fields] [--initial-status]
  issues count <query>
  issues links <key>
  issues link <key> <relationship> <target>
  issues remotelinks <key>
  issues delete-remote-link <key> <linkId>

  # Transitions
  transitions execute <key> <id>

  # Fields
  fields list
  fields get <fieldId> [--expand <fields>]
  fields create <json-body>
  fields update <fieldId> --version <version> <json-body>
  fields categories
  fields category-create <json-body>
  fields category-update <categoryId> --version <version> <json-body>

  # Entities
  entities create <type> <json-body> [--fields f1,f2]
  entities get <type> <id> [--fields f1,f2]
  entities update <type> <id> <json-body> [--fields f1,f2]
  entities search <type> [--input <text>] [--filter <json>] [--order-by <field>] [--order-asc] [--root-only] [--per-page <n>] [--page <n>] [--fields f1,f2]
  entities delete <type> <id> [--with-board]
  entities comment <type> <id> <text>
  entities comments <type> <id> [--expand]
  entities comments-paginated <type> <id> [--per-page <n>] [--from <id>] [--direction asc|desc]
  entities comment-get <type> <id> <commentId> [--expand]
  entities comment-edit <type> <id> <commentId> <text>
  entities comment-delete <type> <id> <commentId>
  entities links <type> <id> [--fields]
  entities add-links <type> <id> <json-array>
  entities delete-link <type> <id> --right <entityId>
  entities attachments <type> <id>
  entities attachment <type> <id> <fileId>
  entities attach-file <type> <id> <fileId>
  entities delete-attachment <type> <id> <fileId>
  entities checklist-add <type> <id> <json-items>
  entities checklist-edit <type> <id> <json-items>
  entities checklist-edit-item <type> <id> <itemId> <json>
  entities checklist-move <type> <id> <itemId> --before <id>
  entities checklist-delete-item <type> <id> <itemId>
  entities checklist-delete-all <type> <id>
  entities bulk-update <type> <json-body>
  entities events <type> <id> [--per-page <n>] [--from <id>] [--direction asc|desc]
  entities permissions <type> <id>
  entities update-permissions <type> <id> <json-body>

  # Projects
  projects comment <id> <text>

  # Queues, Worklog, Boards
  queues get <id> [--expand <fields>]
  queues list [--per-page <n>] [--expand <fields>]
  queues local-fields <queue>
  queues create-local-field <queue> <json-body>
  worklog list <key> [--per-page <n>]
  worklog create <key> --start <datetime> --duration <dur> [--comment <text>]
  worklog edit <key> <worklogId> [--start <datetime>] [--duration <dur>] [--comment <text>]
  worklog delete <key> <worklogId>
  boards list
  boards get <id>
  boards create --name <N> --queue <Q> [--type <T>] [--query <Q>]
  boards update <id> --version <V> <json-body>
  boards delete <id>
  boards columns <id>
  boards column <boardId> <columnId>
  boards create-column <boardId> --version <V> --name <N> --statuses <s1,s2>
  boards update-column <boardId> <columnId> --version <V> <json-body>
  boards delete-column <boardId> <columnId> --version <V>
  boards sprints <id>
  boards sprint <sprintId>
  boards create-sprint --name <N> --board <B> --start <D> --end <D>

Options:
  --expand <fields>
  --json
  --help
```

## Search Query DSL

Search queries use Tracker Query Language with `Field: value` pairs. Multiple conditions are typically combined with spaces or semicolons, for example `Queue: ITAXI Status: Open`.

## Additional References

-   [Examples](references/examples.md)
-   [Entities API](references/entities-api.md)
-   [Fields API](references/fields-api.md)
-   [Query Language](references/query-language.md)
