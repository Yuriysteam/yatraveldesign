---
name: wiki-client
description: Используй для чтения, создания и обновления страниц Яндекс Вики, обхода дочерних страниц, работы с вложениями и преобразования файлов в YFM через wiki-cli.
---

# Вики

Интерфейс командной строки для Яндекс Вики. Поддерживает чтение по адресу или идентификатору, обход дерева, создание, обновление и удаление страниц, вложения и преобразование файлов в YFM. Токен передаётся только через `WIKI_TOKEN`.

## Установка

Используй глобально установленный `wiki-cli`. Если его нет, установи `@yandex-tools/ai-wiki-cli` из `https://npm.yandex-team.ru/`.

## Domain Notes

- `wiki-cli` is a thin wrapper over the Ya.Wiki public REST API
- Pages are identified by slug or numeric id and expose page metadata such as `page_type`, breadcrumbs, revision ids, and readonly state
- Attachments are page-scoped and cursor-paginated
- Attachment download can work by attachment id or by a `/.files/` slug URL
- `attachments file-to-yfm` is the right path when the workflow starts from an uploaded file and needs YFM content
- Wiki search is not part of this client; use `intrasearch-client` for full-text search

## CLI Reference

```bash
wiki-cli <command> [options]

Commands:
  pages get <slug>                       Get page details by slug
  pages get-by-id <id>                   Get page by numeric ID
  pages tree <slug>                      Get page tree/hierarchy
  pages descendants <id>                 Get all descendants
  pages create --title <t> --content <c> --parent-id <id> [--silent]
                                         Create a new page
  pages update <id> [--title <t>] [--content <c>]
                                         Update an existing page
  pages delete <id>                      Delete a page
  attachments list <pageId> [--order-by name|size|created_at] [--order-direction asc|desc] [--page-size <n>] [--cursor <c>]
                                         List page attachments
  attachments download <pageId> <fileId> --output <path>
                                         Download attachment by ID
  attachments preview <pageId> <fileId> --output <path>
                                         Download preview/thumbnail
  attachments download-by-url <url> --output <path> [--download]
                                         Download by slug/.files/name URL
  attachments delete <pageId> <fileId>   Delete an attachment
  attachments file-to-yfm <pageId> --upload-session <uuid>
                                         Convert uploaded file to YFM
  resolve-slug <url>                     Extract slug from Wiki URL

Options:
  --fields <fields>  Comma-separated fields to include
  --json             Output raw JSON
  --help             Show help
```

## Notes

- Wiki search is not provided by this client; use `intrasearch-client` for full-text wiki search.
- `attachments list` is cursor-paginated.

## Additional References

- [Examples](references/examples.md)
