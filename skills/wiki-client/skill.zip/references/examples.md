# Wiki Reference

## Examples

```bash
wiki-cli pages get "users/levitskiydv/my-page"
wiki-cli pages get-by-id 12345
wiki-cli pages tree "taxi/mobile"
wiki-cli pages descendants 12345
wiki-cli pages create --title "My New Page" --content "== Hello ==" --parent-id 98765
wiki-cli pages update 12345 --content "New content here"
wiki-cli attachments list 12345
wiki-cli attachments download 12345 67 --output /tmp/attachment.png
wiki-cli attachments download-by-url "taxi/mobile/.files/diagram.png" --output /tmp/diagram.png
wiki-cli resolve-slug "https://wiki.yandex-team.ru/taxi/mobile/ios/"
```

## Auth

- Environment variable: `WIKI_TOKEN`

## Error Classes

- `WikiApiError`
- `WikiBadRequestError`
- `WikiUnauthorizedError`
- `WikiForbiddenError`
- `WikiNotFoundError`
- `WikiTimeoutError`
- `WikiNetworkError`

## Operational Notes

- `attachments download-by-url` is useful when the user already has a `.files/` link.
- Use `intrasearch-cli` rather than `wiki-cli` for full-text wiki search.
