#!/bin/sh
printf '%s\n' 'Skill загружен и доступен'
